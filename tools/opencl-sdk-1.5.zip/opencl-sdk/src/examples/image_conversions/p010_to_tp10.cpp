//--------------------------------------------------------------------------------------
// File: p010_to_tp10.cpp
// Desc: This program converts P010 to TP10
//
// Author:      QUALCOMM
//
//               Copyright (c) 2017, 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

// Std includes
#include <array>
#include <cstdlib>
#include <cstring>
#include <iostream>
// Project includes
#include "util/cl_wrapper.h"
#include "util/util.h"
// Library includes
#include <CL/cl.h>
#include <CL/cl_ext_qcom.h>


static const char *PROGRAM_SOURCE = R"(
    // This kernel writes from a P010 image (both planes) to a TP10 image.
    // Input image file should have dimensions such that width % 6 is 0.
    __kernel void p010_to_tp10(__read_only  image2d_t src_p010,
                               __write_only image2d_t dest_tp10_y,
                               __write_only image2d_t dest_tp10_uv,
                                            sampler_t sampler)
    {
        const int    wid_x          = get_global_id(0);
        const int    wid_y          = get_global_id(1);
        const int2   read_coord     = (int2)(6 * wid_x, wid_y);
        const int2   y_write_coord  = (int2)(6 * wid_x, wid_y);
        const int2   uv_write_coord = (int2)(3 * wid_x, wid_y / 2);
        const float4 pixels_in[]    = {
            read_imagef(src_p010, sampler, read_coord               ),
            read_imagef(src_p010, sampler, read_coord + (int2)(1, 0)),
            read_imagef(src_p010, sampler, read_coord + (int2)(2, 0)),
            read_imagef(src_p010, sampler, read_coord + (int2)(3, 0)),
            read_imagef(src_p010, sampler, read_coord + (int2)(4, 0)),
            read_imagef(src_p010, sampler, read_coord + (int2)(5, 0)),
            };
        float        y_pixels_out[2][3] = {
            {pixels_in[0].s0, pixels_in[1].s0, pixels_in[2].s0},
            {pixels_in[3].s0, pixels_in[4].s0, pixels_in[5].s0},
            };
        float2       uv_pixels_out[3]   = {
            {pixels_in[0].s1, pixels_in[0].s2},
            {pixels_in[2].s1, pixels_in[2].s2},
            {pixels_in[4].s1, pixels_in[4].s2},
            };
        qcom_write_imagefv_3x1_n10t00(dest_tp10_y, y_write_coord,                y_pixels_out[0]);
        qcom_write_imagefv_3x1_n10t00(dest_tp10_y, y_write_coord + (int2)(3, 0), y_pixels_out[1]);
        if (wid_y % 2 == 0) qcom_write_imagefv_3x1_n10t01(dest_tp10_uv, uv_write_coord, uv_pixels_out);
    }
)";


int main(int argc, char** argv)
{
    if (argc != 3)
    {
        std::cerr << "Usage: " << argv[0] << " <img data file> <out image data file> \n"
                                             "Input image file data should be in format CL_QCOM_P010 / CL_QCOM_UNORM_INT10\n"
                                             "Demonstrates conversions from P010 to TP10\n"
                                             "Input image file should have dimensions such that width % 6 is 0.\n";
        return EXIT_FAILURE;
    }

    const std::string input_image_filename(argv[1]);
    const std::string output_image_filename(argv[2]);

    cl_wrapper          wrapper;
    cl_program          program             = wrapper.make_program(&PROGRAM_SOURCE, 1);
    cl_kernel           p010_to_tp10_kernel = wrapper.make_kernel("p010_to_tp10", program);
    cl_context          context             = wrapper.get_context();
    p010_image_t        input_p010_image_info = load_p010_image_data(input_image_filename);
    struct dma_buf_sync buf_sync            = {};
    cl_event            unmap_event         = nullptr;

    /*
    * Step 0: Confirm the required OpenCL extensions are supported.
    */

    if (!wrapper.check_extension_support("cl_qcom_other_image"))
    {

        std::cerr << "Extension cl_qcom_other_image needed for P010 and TP10 image formats is not supported.";
        return EXIT_FAILURE;
    }

    if (!wrapper.check_extension_support("cl_qcom_ext_host_ptr"))
    {
        std::cerr << "Extension cl_qcom_ext_host_ptr needed for dmabuf-backed images is not supported.\n";
        return EXIT_FAILURE;
    }

    if (!wrapper.check_extension_support("cl_qcom_dmabuf_host_ptr"))
    {
        std::cerr << "Extension cl_qcom_dmabuf_host_ptr needed for dmabuf-backed images is not supported.\n";
        return EXIT_FAILURE;
    }

    if (!wrapper.check_extension_support("cl_qcom_vector_image_ops"))
    {
        std::cerr << "Extension cl_qcom_vector_image_ops needed for vector image reads/writes is not supported.\n";
        return EXIT_FAILURE;
    }

    /*
     * Step 1: Create suitable DMA buffer-backed CL images. Note that planar formats (like P010) must be read only,
     * but you can write to child images derived from the planes. (See step 2 for deriving child images.)
     */

    cl_image_format input_p010_format = {};
    input_p010_format.image_channel_order     = CL_QCOM_P010;
    input_p010_format.image_channel_data_type = CL_QCOM_UNORM_INT10;

    cl_image_desc input_p010_desc = {};
    input_p010_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    input_p010_desc.image_width  = input_p010_image_info.y_width;
    input_p010_desc.image_height = input_p010_image_info.y_height;

    cl_int err = 0;
    cl_mem_dmabuf_host_ptr input_p010_mem = wrapper.make_buffer_for_yuv_image(input_p010_format, input_p010_desc);
    cl_mem input_p010_image = clCreateImage(
            context,
            CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR | CL_MEM_EXT_HOST_PTR_QCOM,
            &input_p010_format,
            &input_p010_desc,
            &input_p010_mem,
            &err
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateImage for input image." << "\n";
        return err;
    }

    cl_image_format output_tp10_format = {};
    output_tp10_format.image_channel_order     = CL_QCOM_TP10;
    output_tp10_format.image_channel_data_type = CL_QCOM_UNORM_INT10;

    cl_image_desc output_tp10_desc = {};
    output_tp10_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    output_tp10_desc.image_width  = input_p010_image_info.y_width;
    output_tp10_desc.image_height = input_p010_image_info.y_height;

    cl_mem_dmabuf_host_ptr output_tp10_mem = wrapper.make_buffer_for_yuv_image(output_tp10_format, output_tp10_desc);
    cl_mem output_tp10_image = clCreateImage(
        context,
        CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR | CL_MEM_EXT_HOST_PTR_QCOM,
        &output_tp10_format,
        &output_tp10_desc,
        &output_tp10_mem,
        &err
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateImage for output image." << "\n";
        return err;
    }

   /*
    * Step 2: Separate planar images into their component planes.
    */

    cl_image_format input_y_plane_format = {};
    input_y_plane_format.image_channel_order     = CL_QCOM_P010_Y;
    input_y_plane_format.image_channel_data_type = CL_QCOM_UNORM_INT10;

    cl_image_desc input_y_plane_desc = {};
    input_y_plane_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    input_y_plane_desc.image_width  = input_p010_image_info.y_width;
    input_y_plane_desc.image_height = input_p010_image_info.y_height;
    input_y_plane_desc.mem_object   = input_p010_image;

    cl_mem input_y_plane = clCreateImage(
            context,
            CL_MEM_READ_ONLY,
            &input_y_plane_format,
            &input_y_plane_desc,
            nullptr,
            &err
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateImage for input image y plane." << "\n";
        return err;
    }

    cl_image_format input_uv_plane_format = {};
    input_uv_plane_format.image_channel_order     = CL_QCOM_P010_UV;
    input_uv_plane_format.image_channel_data_type = CL_QCOM_UNORM_INT10;

    cl_image_desc input_uv_plane_desc = {};
    input_uv_plane_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    // The image dimensions for the uv-plane derived image must be the same as the parent image, even though the
    // actual dimensions of the uv-plane differ by a factor of 2 in each dimension.
    input_uv_plane_desc.image_width  = input_p010_image_info.y_width;
    input_uv_plane_desc.image_height = input_p010_image_info.y_height;
    input_uv_plane_desc.mem_object   = input_p010_image;

    cl_mem input_uv_plane = clCreateImage(
            context,
            CL_MEM_READ_ONLY,
            &input_uv_plane_format,
            &input_uv_plane_desc,
            nullptr,
            &err
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateImage for input image uv plane." << "\n";
        return err;
    }

    cl_image_format output_y_plane_format = {};
    output_y_plane_format.image_channel_order     = CL_QCOM_TP10_Y;
    output_y_plane_format.image_channel_data_type = CL_QCOM_UNORM_INT10;

    cl_image_desc output_y_plane_desc = {};
    output_y_plane_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    output_y_plane_desc.image_width  = output_tp10_desc.image_width;
    output_y_plane_desc.image_height = output_tp10_desc.image_height;
    output_y_plane_desc.mem_object   = output_tp10_image;

    cl_mem output_y_plane = clCreateImage(
            context,
            CL_MEM_WRITE_ONLY,
            &output_y_plane_format,
            &output_y_plane_desc,
            nullptr,
            &err
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateImage for output image y plane." << "\n";
        return err;
    }

    cl_image_format output_uv_plane_format = {};
    output_uv_plane_format.image_channel_order     = CL_QCOM_TP10_UV;
    output_uv_plane_format.image_channel_data_type = CL_QCOM_UNORM_INT10;

    cl_image_desc output_uv_plane_desc = {};
    output_uv_plane_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    // The image dimensions for the uv-plane derived image must be the same as the parent image, even though the
    // actual dimensions of the uv-plane differ by a factor of 2 in each dimension.
    output_uv_plane_desc.image_width  = output_tp10_desc.image_width;
    output_uv_plane_desc.image_height = output_tp10_desc.image_height;
    output_uv_plane_desc.mem_object   = output_tp10_image;

    cl_mem output_uv_plane = clCreateImage(
            context,
            CL_MEM_WRITE_ONLY,
            &output_uv_plane_format,
            &output_uv_plane_desc,
            nullptr,
            &err
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateImage for output image uv plane." << "\n";
        return err;
    }

   /*
    * Step 3: Copy data to input image planes.
    */

    buf_sync.flags = DMA_BUF_SYNC_START | DMA_BUF_SYNC_WRITE;
    if (ioctl(input_p010_mem.dmabuf_filedesc, DMA_BUF_IOCTL_SYNC, &buf_sync))
    {
        std::cerr << "Error preparing the DMA buffer for writes. The DMA_BUF_IOCTL_SYNC operation returned "
                  << strerror(errno) << "!\n";
        return errno;
    }

    cl_command_queue command_queue  = wrapper.get_command_queue();
    const size_t     origin[]       = {0, 0, 0};
    const size_t     input_y_region[] = {input_y_plane_desc.image_width, input_y_plane_desc.image_height, 1};
    size_t           row_pitch      = 0;
    unsigned char   *image_ptr      = static_cast<unsigned char *>(clEnqueueMapImage(
            command_queue,
            input_y_plane,
            CL_BLOCKING,
            CL_MAP_WRITE,
            origin,
            input_y_region,
            &row_pitch,
            nullptr,
            0,
            nullptr,
            nullptr,
            &err
    ));
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " mapping input image y-plane buffer for writing." << "\n";
        return err;
    }

    // Copies image data to the DMA buffer from the host.
    for (uint32_t i = 0; i < input_y_plane_desc.image_height; ++i)
    {
        std::memcpy(
                image_ptr                          + i * row_pitch,
                input_p010_image_info.y_plane.data() + i * input_y_plane_desc.image_width * 2,
                input_y_plane_desc.image_width * 2
        );
    }

    err = clEnqueueUnmapMemObject(command_queue, input_y_plane, image_ptr, 0, nullptr, nullptr);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " unmapping source image y-plane data buffer." << "\n";
        return err;
    }

    // Note the discrepancy between the child plane image descriptor and the size required by clEnqueueMapImage.
    const size_t input_uv_region[] = {input_uv_plane_desc.image_width / 2, input_uv_plane_desc.image_height / 2, 1};
    row_pitch                    = 0;
    image_ptr = static_cast<unsigned char *>(clEnqueueMapImage(
            command_queue,
            input_uv_plane,
            CL_BLOCKING,
            CL_MAP_WRITE,
            origin,
            input_uv_region,
            &row_pitch,
            nullptr,
            0,
            nullptr,
            nullptr,
            &err
    ));
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " mapping input image uv-plane buffer for writing." << "\n";
        return err;
    }

    // Copies image data to the DMA buffer from the host.
    for (uint32_t i = 0; i < input_uv_plane_desc.image_height / 2; ++i)
    {
        std::memcpy(
                image_ptr                           + i * row_pitch,
                input_p010_image_info.uv_plane.data() + i * input_uv_plane_desc.image_width * 2,
                input_uv_plane_desc.image_width * 2
        );
    }

    err = clEnqueueUnmapMemObject(command_queue, input_uv_plane, image_ptr, 0, nullptr, &unmap_event);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " unmapping input image uv-plane data buffer." << "\n";
        return err;
    }

    err = clWaitForEvents(1, &unmap_event);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while waiting to unmap.\n";
        return err;
    }

    err = clReleaseEvent(unmap_event);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseEvent(unmap_event)\n";
        return err;
    }

    buf_sync.flags = DMA_BUF_SYNC_END | DMA_BUF_SYNC_WRITE;
    if (ioctl(input_p010_mem.dmabuf_filedesc, DMA_BUF_IOCTL_SYNC, &buf_sync))
    {
        std::cerr << "Error finalizing the DMA buffer for writes. The DMA_BUF_IOCTL_SYNC operation returned "
                  << strerror(errno) << "!\n";
        return errno;
    }

   /*
    * Step 4: Set up sampler.
    */

    cl_sampler sampler = clCreateSampler(
            context,
            CL_FALSE,
            CL_ADDRESS_CLAMP_TO_EDGE,
            CL_FILTER_NEAREST,
            &err
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateSampler." << "\n";
        return err;
    }

   /*
    * Step 5: Run Kernels.
    */

    err = clSetKernelArg(p010_to_tp10_kernel, 0, sizeof(input_p010_image), &input_p010_image);
    if (err != CL_SUCCESS)
    {
        std::cerr << "\tError " << err << " with clSetKernelArg for argument 0 for p010_to_tp10_kernel." << "\n";
        return err;
    }

    err = clSetKernelArg(p010_to_tp10_kernel, 1, sizeof(output_y_plane), &output_y_plane);
    if (err != CL_SUCCESS)
    {
        std::cerr << "\tError " << err << " with clSetKernelArg for argument 1 for p010_to_tp10_kernel." << "\n";
        return err;
    }

    err = clSetKernelArg(p010_to_tp10_kernel, 2, sizeof(output_uv_plane), &output_uv_plane);
    if (err != CL_SUCCESS)
    {
        std::cerr << "\tError " << err << " with clSetKernelArg for argument 2 for p010_to_tp10_kernel." << "\n";
        return err;
    }

    err = clSetKernelArg(p010_to_tp10_kernel, 3, sizeof(sampler), &sampler);
    if (err != CL_SUCCESS)
    {
        std::cerr << "\tError " << err << " with clSetKernelArg for argument 3 for p010_to_tp10_kernel." << "\n";
        return err;
    }

    const size_t p010_to_tp10_work_size[] = {work_units(input_p010_desc.image_width, 6), input_p010_desc.image_height};
    err = clEnqueueNDRangeKernel(
            command_queue,
            p010_to_tp10_kernel,
            2,
            nullptr,
            p010_to_tp10_work_size,
            nullptr,
            0,
            nullptr,
            nullptr
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "\tError " << err << " with clEnqueueNDRangeKernel for p010_to_tp10_kernel." << "\n";
        return err;
    }

    err = clFinish(command_queue);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while finishing the command queue.\n";
        return err;
    }

    /*
     * Step 6: Copy the data out of the buffers.
     *
     * When converting from P010 to TP10 the size of the planes decreases
     * by a factor of 2 / 3.
     * This is because P010 stores 2 10 bit values + 12 bits padding in a 32 bit word
     * whereas TP10 stores 3 10 bit values with 2 bit padding in a 32 bit word.
     * So the size is reduced by 2 / 3.
     *
     * For P010, y-plane size = w * h * 2 (2 because 2 bytes per pixel in y-plane).
     * So equivalent size in TP10  = w * h * 2 * 2 / 3 = w * h * 4 / 3
     *
     */

    tp10_image_t output_image_info;
    output_image_info.y_width  = output_tp10_desc.image_width;
    output_image_info.y_height = output_tp10_desc.image_height;
    output_image_info.y_plane.resize(output_image_info.y_width * output_image_info.y_height * 4 / 3);
    output_image_info.uv_plane.resize(output_image_info.y_width * output_image_info.y_height * 2 / 3);

    buf_sync.flags = DMA_BUF_SYNC_START | DMA_BUF_SYNC_READ;
    if (ioctl(output_tp10_mem.dmabuf_filedesc, DMA_BUF_IOCTL_SYNC, &buf_sync))
    {
        std::cerr << "Error preparing the DMA buffer for reads. The DMA_BUF_IOCTL_SYNC operation returned "
                  << strerror(errno) << "!\n";
        return errno;
    }

    const size_t output_y_region[] = {output_y_plane_desc.image_width, output_y_plane_desc.image_height, 1};
    row_pitch                   = 0;
    image_ptr = static_cast<unsigned char *>(clEnqueueMapImage(
            command_queue,
            output_y_plane,
            CL_BLOCKING,
            CL_MAP_READ,
            origin,
            output_y_region,
            &row_pitch,
            nullptr,
            0,
            nullptr,
            nullptr,
            &err
    ));
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " mapping output image y-plane buffer for reading." << "\n";
        return err;
    }

    // Copies image data from the DMA buffer to the host.
    for (uint32_t i = 0; i < output_y_plane_desc.image_height; ++i)
    {
        std::memcpy(
                output_image_info.y_plane.data() + i * output_y_plane_desc.image_width * 4 / 3,
                image_ptr                     + i * row_pitch,
                output_y_plane_desc.image_width * 4 / 3
        );
    }

    err = clEnqueueUnmapMemObject(command_queue, output_y_plane, image_ptr, 0, nullptr, nullptr);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " unmapping dest image y-plane buffer." << "\n";
        return err;
    }

    const size_t output_uv_region[] = {output_uv_plane_desc.image_width / 2, output_uv_plane_desc.image_height / 2, 1};
    row_pitch                    = 0;
    image_ptr = static_cast<unsigned char *>(clEnqueueMapImage(
            command_queue,
            output_uv_plane,
            CL_BLOCKING,
            CL_MAP_READ,
            origin,
            output_uv_region,
            &row_pitch,
            nullptr,
            0,
            nullptr,
            nullptr,
            &err
    ));
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " mapping dest image uv-plane buffer for reading." << "\n";
        return err;
    }

    // Copies image data from the DMA buffer to the host.
    for (uint32_t i = 0; i < output_uv_plane_desc.image_height / 2; ++i)
    {
        std::memcpy(
                output_image_info.uv_plane.data() + i * output_uv_plane_desc.image_width * 4 / 3,
                image_ptr                      + i * row_pitch,
                output_uv_plane_desc.image_width * 4 / 3
        );
    }

    err = clEnqueueUnmapMemObject(command_queue, output_uv_plane, image_ptr, 0, nullptr, &unmap_event);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " unmapping output image uv-plane buffer." << "\n";
        return err;
    }

    err = clWaitForEvents(1, &unmap_event);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while waiting to unmap.\n";
        return err;
    }

    clReleaseEvent(unmap_event);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseEvent(unmap_event)\n";
        return err;
    }

    buf_sync.flags = DMA_BUF_SYNC_END | DMA_BUF_SYNC_READ;
    if (ioctl(output_tp10_mem.dmabuf_filedesc, DMA_BUF_IOCTL_SYNC, &buf_sync))
    {
        std::cerr << "Error finalizing the DMA buffer for reads. The DMA_BUF_IOCTL_SYNC operation returned "
                  << strerror(errno) << "!\n";
        return errno;
    }

    save_tp10_image_data(output_image_filename, output_image_info);

    // Clean up cl resources that aren't automatically handled by cl_wrapper
    err = clReleaseSampler(sampler);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseSampler(sampler)\n";
        return err;
    }

    err = clReleaseMemObject(input_uv_plane);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseMemObject(input_uv_plane)\n";
        return err;
    }

    err = clReleaseMemObject(input_y_plane);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseMemObject(input_y_plane)\n";
        return err;
    }

    err = clReleaseMemObject(input_p010_image);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseMemObject(input_p010_image)\n";
        return err;
    }

    err = clReleaseMemObject(output_uv_plane);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseMemObject(output_uv_plane)\n";
        return err;
    }

    err = clReleaseMemObject(output_y_plane);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseMemObject(output_y_plane)\n";
        return err;
    }

    err = clReleaseMemObject(output_tp10_image);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << ": clReleaseMemObject(output_tp10_image)\n";
        return err;
    }

    return EXIT_SUCCESS;
}