//--------------------------------------------------------------------------------------
// File: qcom_priority_hint.cpp
// Desc: This example demonstrates the usage of cl_qcom_priority_hint.
//
// Author:      QUALCOMM
//
// Copyright (c) 2022 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//--------------------------------------------------------------------------------------

#include <cstdio>
#include <cstdlib>
#include <string>

#include <CL/cl.h>
#include <CL/cl_ext_qcom.h>

#define HANDLE_ERROR(status, format, ...)                           \
if(status != CL_SUCCESS)                                            \
{                                                                   \
    fprintf(stderr, "%s:%d [Error: 0x%x] " format,                  \
            __FILE__, __LINE__, status __VA_OPT__(,) __VA_ARGS__);  \
    exit(EXIT_FAILURE);                                             \
}

static const size_t global_work_size = 128;

// A kernel to sum the first N numbers.
static const char* PROGRAM_SOURCE = R"(
    __kernel void sum_numbers(__global int *sums) {
        int gid = get_global_id(0);
        sums[gid] = 0;
        for(int i = 0; i < gid; i++) {
            sums[gid] += i;
        }
    }
)";

typedef struct _work_info {
    cl_device_id          device_id;
    cl_context_properties context_properties[3];
    cl_context            context;
    cl_command_queue      command_queue;
    cl_mem                gpu_buffer;
    cl_program            program;
    cl_kernel             kernel;
} work_info;

bool check_extension_support(cl_device_id device_id, const std::string &desired_extension) {
    size_t extensions_size = 0;
    cl_int status;

    status = clGetDeviceInfo(device_id, CL_DEVICE_EXTENSIONS, 0, nullptr, &extensions_size);
    HANDLE_ERROR(status, "clGetDeviceInfo with CL_DEVICE_EXTENSIONS failed to get extensions string size.\n");

    std::string extensions;
    extensions.resize(extensions_size);
    status = clGetDeviceInfo(device_id, CL_DEVICE_EXTENSIONS, extensions_size, extensions.data(), nullptr);
    HANDLE_ERROR(status, "clGetDeviceInfo with CL_DEVICE_EXTENSIONS failed to get extensions string.\n");

    if (extensions.size() == 0)
    {
        fprintf(stderr, "%s:%d Couldn't identify available OpenCL extensions.\n", __FILE__, __LINE__);
        exit(EXIT_FAILURE);
    }

    return extensions.find(desired_extension) != std::string::npos;
}

// Create the OpenCL objects: context, command queue, buffer, program, kernel
// needed for running workloads with different priority levels.
void setup_work(work_info &wd)
{
    cl_int       status    = CL_SUCCESS;
    cl_device_id device_id = wd.device_id;

    wd.context = clCreateContext(wd.context_properties, 1, &device_id, nullptr, nullptr, &status);
    HANDLE_ERROR(status, "clCreateContext\n");

    wd.command_queue = clCreateCommandQueue(wd.context, device_id, 0, &status);
    HANDLE_ERROR(status, "clCreateCommandQueue\n");

    wd.gpu_buffer = clCreateBuffer(wd.context, CL_MEM_READ_WRITE, global_work_size * sizeof(cl_int), nullptr, &status);
    HANDLE_ERROR(status, "clCreateBuffer with CL_MEM_READ_WRITE.\n");

    wd.program = clCreateProgramWithSource(wd.context, 1, &PROGRAM_SOURCE, nullptr, &status);
    HANDLE_ERROR(status, "clCreateProgramWithSource\n");

    status = clBuildProgram(wd.program, 1, &device_id, nullptr, nullptr, nullptr);
    HANDLE_ERROR(status, "clBuildProgram\n");

    wd.kernel = clCreateKernel(wd.program, "sum_numbers", &status);
    HANDLE_ERROR(status, "clCreateKernel\n");

    status = clSetKernelArg(wd.kernel, 0, sizeof(cl_mem), &wd.gpu_buffer);
    HANDLE_ERROR(status, "clSetKernelArg for argument 0.\n");
}

void enqueue_kernel(work_info &wd)
{
    cl_int status;

    status = clEnqueueNDRangeKernel(wd.command_queue, wd.kernel, 1,
                                    nullptr, &global_work_size,
                                    nullptr, 0, nullptr, nullptr);

    HANDLE_ERROR(status, "clEnqueueNDRangeKernel\n");
}

void clean_up(work_info &wd)
{
    cl_int status;

    status = clReleaseKernel(wd.kernel);
    HANDLE_ERROR(status, "clReleaseKernel\n");

    status = clReleaseProgram(wd.program);
    HANDLE_ERROR(status, "clReleaseProgram\n");

    status = clReleaseMemObject(wd.gpu_buffer);
    HANDLE_ERROR(status, "clReleaseMemObject\n");

    status = clReleaseCommandQueue(wd.command_queue);
    HANDLE_ERROR(status, "clReleaseCommandQueue\n");

    status = clReleaseContext(wd.context);
    HANDLE_ERROR(status, "clReleaseContext\n");
}

int main(int argc, char **argv)
{
    cl_uint        num_devices;
    cl_platform_id platform_id = NULL;
    cl_device_id   device_id   = NULL;
    cl_int         status      = CL_SUCCESS;

    status = clGetPlatformIDs(1, &platform_id, nullptr);
    HANDLE_ERROR(status, "clGetPlatformIDs\n");

    status = clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_GPU, 1, &device_id, &num_devices);
    HANDLE_ERROR(status, "clGetDeviceIDs with CL_DEVICE_TYPE_GPU.\n");

    if(!check_extension_support(device_id, "cl_qcom_priority_hint"))
    {
        fprintf(stderr, "This device does not support cl_qcom_priority_hint.\n");
        exit(EXIT_FAILURE);
    }

    // Setup different contexts on the same device for queuing kernels with different priorities.
    //
    //                      - Device -,                 ----- context properties -----
    work_info prio_low    = {device_id, {CL_CONTEXT_PRIORITY_HINT_QCOM, CL_PRIORITY_HINT_LOW_QCOM,    0}};
    work_info prio_normal = {device_id, {CL_CONTEXT_PRIORITY_HINT_QCOM, CL_PRIORITY_HINT_NORMAL_QCOM, 0}};
    work_info prio_high   = {device_id, {CL_CONTEXT_PRIORITY_HINT_QCOM, CL_PRIORITY_HINT_HIGH_QCOM,   0}};

    setup_work(prio_low);
    setup_work(prio_normal);
    setup_work(prio_high);

    // Enqueue some kernels with different priorities.
    enqueue_kernel(prio_low);
    enqueue_kernel(prio_normal);
    enqueue_kernel(prio_high);

    // Wait for the kernels to finish execution.
    status = clFinish(prio_low.command_queue);
    HANDLE_ERROR(status, "clFinish for Low Priority Command Queue.\n");

    status = clFinish(prio_normal.command_queue);
    HANDLE_ERROR(status, "clFinish for Normal Priority Command Queue.\n");

    status = clFinish(prio_high.command_queue);
    HANDLE_ERROR(status, "clFinish for High Priority Command Queue.\n");

    // Release all the allocated objects.
    clean_up(prio_low);
    clean_up(prio_normal);
    clean_up(prio_high);

    return EXIT_SUCCESS;
}
