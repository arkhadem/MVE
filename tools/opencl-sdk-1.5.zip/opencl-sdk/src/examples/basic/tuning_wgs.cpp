//---------------------------------------------------------------------------------------------------------------------
// File: tuning_wgs.cpp
// Desc: This program shows how to tune the work group size of a kernel for better performance.
//
// Author:      QUALCOMM
//
//               Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//---------------------------------------------------------------------------------------------------------------------

// Std includes
#include <limits>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <cmath>

// Project includes
#include "util/cl_wrapper.h"

// Convert nanoseconds to milliseconds
#define NS_TO_MS(x) ((x) / 1000000.0)

// Convert char to int
#define CHAR_TO_INT(x) ((int)x-(int)'0')

// This sample demonstrates tuning a 2-D work-load, the same principle also applies to 1-D and 3-D work-load.
static const int    WORK_DIM = 2;
static const char* PROGRAM_SOURCE = R"(
    __kernel void transpose(__global int *matrix,
                                     unsigned int width,
                                     unsigned int height)
    {
        const unsigned long x = get_global_id(0);
        const unsigned long y = get_global_id(1);

        if (x > y)
        {
            const unsigned long idx   = width * y + x;
            const unsigned long idx_t = height * x + y;
            int temp = matrix[idx];
            matrix[idx] = matrix[idx_t];
            matrix[idx_t] = temp;
        }
    }
)";

int main(int argc, char** argv)
{
    static const      cl_queue_properties QUEUE_PROPERTIES[] = { CL_QUEUE_PROPERTIES, CL_QUEUE_PROFILING_ENABLE, 0 };
    cl_wrapper        wrapper(nullptr, QUEUE_PROPERTIES);
    cl_int            errcode                                = 0;
    int*              source_buffer                          = nullptr;
    int*              destination_buffer                     = nullptr;
    cl_context        context                                = wrapper.get_context();
    cl_command_queue  queue                                  = wrapper.get_command_queue();
    cl_program        program                                = wrapper.make_program(&PROGRAM_SOURCE, 1, "-cl-std=CL2.0");
    cl_kernel         kernel                                 = wrapper.make_kernel("transpose", program);
    cl_device_id      device                                 = wrapper.get_device_id();
    cl_event          event                                  = nullptr;
    cl_ulong          start_time                             = 0;
    cl_ulong          end_time                               = 0;
    cl_mem            source_mem                             = nullptr;
    double            default_exec_time                      = 0;
    double            best_exec_time                         = std::numeric_limits<double>::max();
    size_t            local_work_size[]                      = { 0, 0 };
    size_t            current_iter_workgroup_size[]          = { 1, 1 };
    size_t            best_workgroup_size[]                  = { 0, 0 };
    int               num_mismatches                         = 0;
    int               max_workgroup_size                     = 0;
    size_t            wg_multiple                            = 0;
    size_t            total_work_items                       = 0;
    size_t            global_work_size[]                     = { 0, 0};

    /*
     * Help Message
    */
    std::cout << "\nSample: " << argv[0] << "\n"
        "\tThis sample implements an Inplace Matrix Transpose operation on the Source Buffer.\n"
        "\tUse it to find the best local work group size in terms of least execution time.\n";

    // Find current device's max memory object allocation size in bytes.
    cl_ulong max_mem_obj_alloc_size = 0;
    size_t   square_matrix_row_length = 0;

    errcode = clGetDeviceInfo(device,
        CL_DEVICE_MAX_MEM_ALLOC_SIZE,
        sizeof(max_mem_obj_alloc_size),
        &max_mem_obj_alloc_size,
        NULL);
    HANDLE_ERROR(errcode,
        "error in clGetDeviceInfo while querying for CL_DEVICE_MAX_MEM_ALLOC_SIZE.");
    std::cout << "\n The CL_DEVICE_MAX_MEM_ALLOC_SIZE: ["<< max_mem_obj_alloc_size << "] returned by driver.\n";

    square_matrix_row_length = (size_t)sqrt(max_mem_obj_alloc_size / (sizeof(int)));
    total_work_items = square_matrix_row_length * square_matrix_row_length;
    global_work_size[0] = square_matrix_row_length;
    global_work_size[1] = square_matrix_row_length;

    std::cout << "\n The row length of square matrix is: [" << square_matrix_row_length << "].\n";

    /*
    * <pre-processing>
    * Step 0: Querry Device for Max Work Items in a single Work Group i.e. Work Group Size
    *         and Preferred Work Group Size Multiple i.e. step size to iterate the Local Work Group Size
    */

    size_t device_max_workgroup_size = 0;
    size_t device_workgoup_size_multiple = 0;
    size_t device_max_workitems_per_dimension[] = { 0,0,0 };

    errcode = clGetDeviceInfo(device,
        CL_DEVICE_MAX_WORK_GROUP_SIZE,
        sizeof(device_max_workgroup_size),
        &device_max_workgroup_size,
        NULL);
    HANDLE_ERROR(errcode, "error in clGetDeviceInfo while querying for CL_DEVICE_MAX_WORK_GROUP_SIZE.");
    std::cout << "\n The CL_DEVICE_MAX_WORK_GROUP_SIZE: [" << device_max_workgroup_size << "] returned by driver.\n";

    char device_version[50] = { '\0' };
    errcode = clGetDeviceInfo(device,
        CL_DEVICE_VERSION,
        sizeof(device_version),
        &device_version,
        NULL);
    HANDLE_ERROR(errcode, "error in clGetDeviceInfo while querying for CL_DEVICE_VERSION.");
    std::cout << "\n The CL_DEVICE_VERSION returned by driver is: [" << device_version << "] returned by driver.\n";

    if (CHAR_TO_INT(device_version[strlen("OpenCl ")]) >= 3) // only if version is >= 3.0
    {
        errcode = clGetDeviceInfo(device,
            CL_DEVICE_PREFERRED_WORK_GROUP_SIZE_MULTIPLE,
            sizeof(device_workgoup_size_multiple),
            &device_workgoup_size_multiple,
            nullptr);
        HANDLE_ERROR(errcode,
            "error in clGetDeviceInfo while querying for CL_DEVICE_PREFERRED_WORK_GROUP_SIZE_MULTIPLE.");
        std::cout << "\n The CL_DEVICE_PREFERRED_WORK_GROUP_SIZE_MULTIPLE: [" <<
        device_workgoup_size_multiple << "] returned by driver.\n";
    }

    errcode = clGetDeviceInfo(device,
        CL_DEVICE_MAX_WORK_ITEM_SIZES,
        sizeof(device_max_workitems_per_dimension),
        device_max_workitems_per_dimension,
        NULL);
    HANDLE_ERROR(errcode,
        "error in clGetDeviceInfo while querying for CL_DEVICE_MAX_WORK_ITEM_SIZES.");
    std::cout << "\n The CL_DEVICE_MAX_WORK_ITEM_SIZES in each direction: [" << device_max_workitems_per_dimension[0]<<
        "," << device_max_workitems_per_dimension[1] << "," << device_max_workitems_per_dimension[2] << "] returned by driver\n";
    for (int i = 0; i < WORK_DIM; i++) {
        local_work_size[i] = std::min( device_max_workgroup_size ,
            device_max_workitems_per_dimension[i]);
        if (max_workgroup_size < device_max_workitems_per_dimension[i])
        {
            max_workgroup_size = device_max_workitems_per_dimension[i];
        }
    }

    /*
    * <pre-processing>
    * Step 1: Querry Kernel for Max Work Items in 1 Work Group aka Work Group Size
    *         and Preferred Work Group Size Multiple aka step size to iterate the Local Work Group Size
    */
    size_t kernel_workgroup_size = 0;
    size_t kernel_workgroup_size_multiple = 0;
    size_t kernel_compile_workgroup_size[] = { 0, 0, 0 };

    //Query kernel work group size to determine if our local_work_size needs to be aligned to an integer multiple.
    errcode = clGetKernelWorkGroupInfo(kernel,
        device,
        CL_KERNEL_WORK_GROUP_SIZE,
        sizeof(kernel_workgroup_size),
        &kernel_workgroup_size,
        NULL);
    HANDLE_ERROR(errcode,
        "error in clGetKernelWorkGroupInfo while querying for CL_KERNEL_WORK_GROUP_SIZE.");
    std::cout << "\n The CL_KERNEL_WORK_GROUP_SIZE: [" << kernel_workgroup_size << "] returned by driver.\n";
    for (int i = 0; i < WORK_DIM; i++) {
        if (kernel_workgroup_size < local_work_size[i])
        {
            local_work_size[i] = kernel_workgroup_size;
        }
    }
    if (max_workgroup_size < kernel_workgroup_size)
    {
        max_workgroup_size = kernel_workgroup_size;
    }

    errcode = clGetKernelWorkGroupInfo(kernel,
        device,
        CL_KERNEL_COMPILE_WORK_GROUP_SIZE,
        sizeof(kernel_compile_workgroup_size),
        kernel_compile_workgroup_size,
        NULL);
    HANDLE_ERROR(errcode,
        "error in clGetKernelWorkGroupInfo while querying for CL_KERNEL_COMPILE_WORK_GROUP_SIZE.");
    std::cout << "\n The CL_KERNEL_COMPILE_WORK_GROUP_SIZE: [" << kernel_compile_workgroup_size[0] << "," <<
        kernel_compile_workgroup_size[1] << "," << kernel_compile_workgroup_size[2] << "] returned by driver.\n";
    for (int i = 0; i < WORK_DIM; i++) {
        if (kernel_compile_workgroup_size[i] != 0 && kernel_compile_workgroup_size[i] < kernel_workgroup_size)
        {
            local_work_size[i] = kernel_compile_workgroup_size[i];
        }
    }

    // Query kernel work group size to determine if our local_work_size needs to be aligned to an integer multiple.
    errcode = clGetKernelWorkGroupInfo(kernel,
        device,
        CL_KERNEL_PREFERRED_WORK_GROUP_SIZE_MULTIPLE,
        sizeof(kernel_workgroup_size_multiple),
        &kernel_workgroup_size_multiple,
        NULL);
    HANDLE_ERROR(errcode,
        "error in clGetKernelWorkGroupInfo while querying for CL_KERNEL_PREFERRED_WORK_GROUP_SIZE_MULTIPLE.");
    std::cout << "\n The CL_KERNEL_PREFERRED_WORK_GROUP_SIZE_MULTIPLE: [" << kernel_workgroup_size_multiple <<
        "] returned by driver.\n";
    if (kernel_workgroup_size_multiple <= device_max_workgroup_size)
    {
        wg_multiple = kernel_workgroup_size_multiple;
    }
    else
    {
        wg_multiple = device_workgoup_size_multiple;
    }

    /*
     * Step 2. Setup the source buffer, destination buffers and kernel arguments
     */
    source_buffer = (int*)malloc(sizeof(int) * total_work_items);
    HANDLE_ERROR((source_buffer == nullptr) ? -1 : CL_SUCCESS, "malloc failed for source buffer.");
    destination_buffer = (int*)malloc(sizeof(int) * total_work_items);
    HANDLE_ERROR((destination_buffer == nullptr) ? -1 : CL_SUCCESS, "malloc failed for destination buffer.");

    // initialize source buffer
    for (int y = 0; y < global_work_size[1]; y++)
    {
        for (int x = 0; x < global_work_size[0]; x++)
        {
            uint i = y * global_work_size[0] + x;
            source_buffer[i] = i;
        }
    }

    source_mem = clCreateBuffer(context,
        CL_MEM_READ_WRITE | CL_MEM_COPY_HOST_PTR,
        sizeof(int) * total_work_items,
        source_buffer,
        &errcode);
    HANDLE_ERROR(errcode, "error in clCreateBuffer while allocating source buffer.");

    // Set source buffer argument
    errcode = clSetKernelArg(kernel, 0, sizeof(cl_mem), &source_mem);
    HANDLE_ERROR(errcode, "error in clSetKernelArg while setting first argument.");

    // Set global work size in x direction
    errcode = clSetKernelArg(kernel, 1, sizeof(cl_int), &global_work_size[0]);
    HANDLE_ERROR(errcode, "error in clSetKernelArg while setting second argument.");

    // Set work size in y direction
    errcode = clSetKernelArg(kernel, 2, sizeof(cl_int), &global_work_size[1]);
    HANDLE_ERROR(errcode, "error in clSetKernelArg while setting third argument.");

    /*
     * Step 3. Finding the Best Work Group Size by
     *         Iteratively passing all workgroup size combinations to CLEnqueNDRangeKernel
    */
    for (size_t size_y = 1; size_y <= local_work_size[1]; size_y++)
    {
        for (size_t size_x = 1; size_x <= local_work_size[0]; size_x++)
        {
            // Check if we exceed the work_group_size limit
            if ((size_x * size_y) <= max_workgroup_size)
            {
                // If local_work_size is not multiple of wg_multiple skip current combination
                if ((size_x * size_y) % wg_multiple)
                {
                    continue;
                }
                current_iter_workgroup_size[0] = size_x;
                current_iter_workgroup_size[1] = size_y;

                // Execute kernel
                errcode = clEnqueueNDRangeKernel(
                    queue,
                    kernel,
                    WORK_DIM,
                    nullptr,
                    global_work_size,
                    current_iter_workgroup_size,
                    0,
                    nullptr,
                    &event);
                errcode = clWaitForEvents(1, &event);
                HANDLE_ERROR(errcode, "error while waiting for event.");

                // Copy kernel output to destination host buffer
                errcode = clEnqueueReadBuffer(queue,
                    source_mem,
                    CL_BLOCKING,
                    0,
                    total_work_items * sizeof(int),
                    destination_buffer,
                    0,
                    nullptr,
                    nullptr);
                HANDLE_ERROR(errcode,
                    "error in clEnqueueReadBuffer while reading result buffer.");
                for (int y = 0; y < global_work_size[1]; y++)
                {
                    for (int x = 0; x < global_work_size[0]; x++)
                    {
                        if (destination_buffer[x * global_work_size[0] + y] !=
                            source_buffer[y * global_work_size[0] + x])
                        {
                            num_mismatches++;
                            std::cout << x << "\t" << y << "\toutput " << destination_buffer[x * global_work_size[0] + y] <<
                                "\tinput " << source_buffer[y * global_work_size[0] + x] << "\n";
                        }
                    }
                }
                HANDLE_ERROR(num_mismatches, "value mismatches in kernel output.");

                /*
                 * Calculating execution time for each workgroup size
                */
                errcode = clGetEventProfilingInfo(
                    event,
                    CL_PROFILING_COMMAND_START,
                    sizeof(start_time),
                    &start_time,
                    nullptr);
                HANDLE_ERROR(errcode,
                    "error in clGetEventProfilingInfo while querying for CL_PROFILING_COMMAND_START.");
                errcode = clGetEventProfilingInfo(
                    event,
                    CL_PROFILING_COMMAND_END,
                    sizeof(end_time),
                    &end_time,
                    nullptr);
                HANDLE_ERROR(errcode,
                    "error in clGetEventProfilingInfo while querying for CL_PROFILING_COMMAND_END.");
                double execution_time = NS_TO_MS(end_time - start_time) ;

                /*
                 * Determining Best execution time
                */
                if (execution_time < best_exec_time)
                {
                    best_exec_time = execution_time;
                    best_workgroup_size[0] = current_iter_workgroup_size[0];
                    best_workgroup_size[1] = current_iter_workgroup_size[1];
                }
                // Since the kernel is inplace-transpose we need to initialize the source buffer before every iteration.
                errcode = clEnqueueWriteBuffer(queue,
                    source_mem,
                    CL_TRUE,
                    0,
                    sizeof(int) * total_work_items,
                    source_buffer,
                    0,
                    NULL,
                    NULL);
                HANDLE_ERROR(errcode, "error while writing to buffer.");
                clReleaseEvent(event);
            }
        }
    }

    /*
     * Determining Default execution time.
     * Default is Local Work Group Size = nullptr
    */
    errcode = clEnqueueNDRangeKernel(
        queue,
        kernel,
        WORK_DIM,
        nullptr,
        global_work_size,
        nullptr,
        0,
        nullptr,
        &event);
    errcode = clWaitForEvents(1, &event);
    HANDLE_ERROR(errcode, "error in clCreateBuffer for default execution time.");

    errcode = clGetEventProfilingInfo(
        event,
        CL_PROFILING_COMMAND_START,
        sizeof(start_time),
        &start_time,
        nullptr);
    HANDLE_ERROR(errcode, "error in clCreateBuffer for default execution time.");

    errcode = clGetEventProfilingInfo(
        event,
        CL_PROFILING_COMMAND_END,
        sizeof(end_time),
        &end_time,
        nullptr);
    HANDLE_ERROR(errcode, "error in clGetEventProfilingInfo.");

    default_exec_time = NS_TO_MS(end_time - start_time);
    const int  PERCENT = 100;
    const int  PRECISION = 2;
    std::cout << "\nCL app successfully completed!\n\n"
        "The best work group size is:\nX\tY\n"
        << best_workgroup_size[0] << "\t" << best_workgroup_size[1] << "\n\n"
        "The Best Execution Time is:\t\t" << best_exec_time << " milli seconds\n"
        "The Default Execution Time is:\t\t" << default_exec_time << " milli seconds\n"
        "Improvement with Tuned workgroup is:\t" << std::fixed << std::setprecision(PRECISION)
        << (default_exec_time - best_exec_time) / default_exec_time * PERCENT << "%\n";

    /*
     * Step 4. Clean up resources that aren't automatically handled by cl_wrapper
    */
    free(source_buffer);
    free(destination_buffer);
    clReleaseEvent(event);
    clReleaseMemObject(source_mem);
}
