//--------------------------------------------------------------------------------------
// File: onchip_global_memory_image_nv12.cpp
// Desc: Demonstrating usage of cl_qcom_onchip_global_memory for planar images
//
// Author:      QUALCOMM
//
//               Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

#include <string>
#include <cstdlib>

#include <CL/cl.h>
#include <CL/cl_ext_qcom.h>

#include "util/cl_wrapper.h"
#include "util/util.h"

/*
 * This sample shows how to back a planar (NV12) image using a buffer in
 * onchip global memory (effectively storing the image in onchip global
 * memory).
 *
 * 1. Kernel "draw_circle" generates an image of a circle in RGBA
 *    format in onchip global memory.
 *
 * 2. Kernel "rgba_to_nv12_bt709" then converts this RGBA image
 *    into an NV12 image also residing in onchip global memory
 *    at a different offset (this is achieved by backing the image
 *    with an onchip global memory buffer).
 *
 * 3. Kernel "blur" then applies a blur to the NV12 image in
 *    the previous step and writes it to normal DMA-BUF
 *    backed global memory.
 *
 * 4. The final NV12 image data is then read from this DMA-BUF-BACKED
 *    buffer into host memory and written to a file.
 *
 */

static const char *PROGRAM_SOURCE = R"(
    __constant sampler_t sampler = CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE | CLK_FILTER_NEAREST;
    __constant float4 circle_color = (float4) (0.859f, 0.196f, 0.212f, 1.0f);
    __constant float4 background_color = (float4) (0.961f, 0.961f, 0.863f, 1.0f);

    __kernel void draw_circle(__write_only image2d_t image, int radius)
    {
        const uint size_x = get_global_size(0);
        const uint size_y = get_global_size(1);

        const int x = get_global_id(0);
        const int y = get_global_id(1);

        const int xt = x - (size_x / 2);
        const int yt = y - (size_y / 2);

        if(((xt * xt) + (yt * yt)) < (radius * radius))
        {
            write_imagef(image, (int2)(x, y), circle_color);
        }
        else
        {
            write_imagef(image, (int2)(x, y), background_color);
        }
    }

    __kernel void rgba_to_nv12_bt709(__read_only  image2d_t input_rgba,
                                     __write_only image2d_t out_nv12_y,
                                     __write_only image2d_t out_nv12_uv)
    {
        int2   coord;
        float4 ys[4];
        float4 uv;
        float4 rgba_avg;
        float4 rgbas[4];

        coord.x = 2 * get_global_id(0);
        coord.y = 2 * get_global_id(1);

        rgbas[0] = read_imagef(input_rgba, sampler, coord);
        rgbas[1] = read_imagef(input_rgba, sampler, coord + (int2)(0, 1));
        rgbas[2] = read_imagef(input_rgba, sampler, coord + (int2)(1, 0));
        rgbas[3] = read_imagef(input_rgba, sampler, coord + (int2)(1, 1));

        rgba_avg = (float4)(0.0f, 0.0f, 0.0f, 0.0f);
        for (int i = 0; i < 4; ++i)
        {
            ys[i].x   = (0.2126f * rgbas[i].x) + (0.7152f * rgbas[i].y) + (0.0722f * rgbas[i].z);
            ys[i].x   = (219.0f * ys[i].x + 16.0f) / 255.0f;
            rgba_avg += rgbas[i];
        }
        rgba_avg /= 4.0f;
        uv.x      = (-0.1146f * rgba_avg.x) + (-0.3854f * rgba_avg.y) + ( 0.5000f * rgba_avg.z) + 0.5f;
        uv.y      = ( 0.5000f * rgba_avg.x) + (-0.4541f * rgba_avg.y) + (-0.0458f * rgba_avg.z) + 0.5f;
        uv.x      = (224.0f * uv.x + 16.0f) / 255.0f;
        uv.y      = (224.0f * uv.y + 16.0f) / 255.0f;

        write_imagef(out_nv12_y,  coord, ys[0]);
        write_imagef(out_nv12_y,  coord + (int2)(0, 1), ys[1]);
        write_imagef(out_nv12_y,  coord + (int2)(1, 0), ys[2]);
        write_imagef(out_nv12_y,  coord + (int2)(1, 1), ys[3]);
        write_imagef(out_nv12_uv, coord / 2, uv);
    }

    __kernel void blur(__read_only image2d_t image_in,
                       __write_only image2d_t nv12_y_out,
                       __write_only image2d_t nv12_uv_out)
    {
        const uint size_x = get_global_size(0);
        const uint size_y = get_global_size(1);

        const int x = get_global_id(0);
        const int y = get_global_id(1);

        const int blur_size = 20;

        float4 pix;

        float4 out = (float4)(0, 0, 0, 0);
        for(int i = (x - blur_size); i < (x + blur_size); i++) {
            for(int j = (y - blur_size); j < (y + blur_size); j++) {
                if(i < 0 || j < 0 || i >= size_x || j >= size_y) {
                    pix = read_imagef(image_in, sampler, (int2)(0, 0));
                }
                else {
                    pix = read_imagef(image_in, sampler, (int2)(i, j));
                }
                out += pix;
            }
        }
        out /= (2 * 2 * blur_size * blur_size);

        float4 uv;
        uv.xy = out.yz;

        write_imagef(nv12_y_out, (int2)(x, y), out);

        if(!((x & 1) || (y & 1)))
        {
            write_imagef(nv12_uv_out, (int2)(x >> 1, y >> 1), uv);
        }
    }
)";

static const cl_int  circle_radius = 60;
static const cl_uint image_width   = 300;
static const cl_uint image_height  = 300;

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        printf("Usage: %s <Output Image File Name>\n", argv[0]);
        return EXIT_FAILURE;
    }

    std::string output_file_name = argv[1];

    cl_int err = CL_SUCCESS;

    cl_wrapper          wrapper;
    cl_program          program        = wrapper.make_program(&PROGRAM_SOURCE, 1);
    cl_kernel           kernel_circle  = wrapper.make_kernel("draw_circle", program);
    cl_kernel           kernel_convert = wrapper.make_kernel("rgba_to_nv12_bt709", program);
    cl_kernel           kernel_blur    = wrapper.make_kernel("blur", program);
    cl_device_id        device_id      = wrapper.get_device_id();
    cl_context          context        = wrapper.get_context();
    cl_command_queue    command_queue  = wrapper.get_command_queue();

    cl_command_queue  recordable_queue;
    cl_recording_qcom recording;

    // Mem object for the RGBA image in onchip global memory
    cl_mem image_circle_rgba;

    // Mem objects for NV12 image in onchip global memory
    cl_mem buffer_circle_nv12;
    cl_mem image_circle_nv12;
    cl_mem image_circle_y_plane;
    cl_mem image_circle_uv_plane;

    // Mem objects for the final output NV12 image
    cl_mem_dmabuf_host_ptr out_nv12_mem;
    cl_mem out_nv12_image;
    cl_mem out_y_plane;
    cl_mem out_uv_plane;

    size_t image_size_bytes = image_width * image_height * sizeof(cl_uchar4);
    size_t work_size[]      = {image_width, image_height};

    /*
     * Confirm the required OpenCL extensions are supported on device.
     */
    HANDLE_ERROR(!wrapper.check_extensions_support({
        "cl_qcom_onchip_global_memory",
        "cl_qcom_recordable_queues", // recordable queues are used to retain content of onchip global memory between kernels
        "cl_qcom_ext_host_ptr",
        "cl_qcom_dmabuf_host_ptr",
        "cl_qcom_other_image" // for NV12 images
    }), "\nOne or more extensions needed for this sample are not supported on this device\nExiting..\n");

    size_t available_onchip_global_memory;
    err = clGetDeviceInfo(device_id, CL_DEVICE_ONCHIP_GLOBAL_MEM_SIZE_QCOM, sizeof(available_onchip_global_memory), &available_onchip_global_memory, nullptr);
    HANDLE_ERROR(err, "clGetDeviceInfo [CL_DEVICE_ONCHIP_GLOBAL_MEM_SIZE_QCOM]\n");
    printf("Available onchip global memory: %zu\n", available_onchip_global_memory);

    /*
     * Create image object for the RGBA image in onchip global memory.
     */

    cl_image_format rgba_format = {};
    rgba_format.image_channel_order = CL_RGBA;
    rgba_format.image_channel_data_type = CL_UNORM_INT8;

    cl_image_desc rgba_desc = {};
    rgba_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
    rgba_desc.image_width = image_width;
    rgba_desc.image_height = image_height;

    cl_mem_properties image_properties[5] = {CL_MEM_ONCHIP_GLOBAL_QCOM, 1, CL_MEM_ONCHIP_GLOBAL_OFFSET_QCOM, 0, 0};
    image_circle_rgba = clCreateImageWithProperties(context, image_properties, CL_MEM_READ_WRITE | CL_MEM_HOST_NO_ACCESS, &rgba_format, &rgba_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImageWithProperties [CL_MEM_ONCHIP_GLOBAL_QCOM] for image_circle_rgba at offset: %u of size %zu.\n", 0, image_size_bytes);
    printf("\nAllocated onchip global memory for RGBA image (W%u, H%u):\nsize: %zu bytes\noffset: %u bytes\n\n", image_width, image_height, image_size_bytes, 0);

    /*
     * Create image and mem objects for the NV12 image in onchip global memory.
     */

    cl_image_format nv12_format = {};
    nv12_format.image_channel_order = CL_QCOM_NV12;
    nv12_format.image_channel_data_type = CL_UNORM_INT8;

    cl_image_desc nv12_desc = {};
    nv12_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
    nv12_desc.image_width = image_width;
    nv12_desc.image_height = image_height;

    size_t image_size_bytes_nv12;
    err = clQueryImageInfoQCOM(device_id, CL_MEM_READ_ONLY, &nv12_format, &nv12_desc, CL_IMAGE_SIZE_QCOM, sizeof(image_size_bytes_nv12), &image_size_bytes_nv12, nullptr);
    HANDLE_ERROR(err, "clQueryImageInfoQCOM for CL_IMAGE_SIZE_QCOM\n");

    size_t alignment_nv12;
    err = clQueryImageInfoQCOM(device_id, CL_MEM_READ_ONLY, &nv12_format, &nv12_desc, CL_IMAGE_BASE_ADDRESS_ALIGNMENT_QCOM, sizeof(alignment_nv12), &alignment_nv12, nullptr);
    HANDLE_ERROR(err, "clQueryImageInfoQCOM for CL_IMAGE_BASE_ADDRESS_ALIGNMENT_QCOM\n");

    // images must be placed at an offset aligned to CL_IMAGE_BASE_ADDRESS_ALIGNMENT_QCOM
    cl_ulong offset_for_nv12_image = ((image_size_bytes + alignment_nv12 - 1) / alignment_nv12) * alignment_nv12;

    cl_mem_properties buffer_properties[5] = {CL_MEM_ONCHIP_GLOBAL_QCOM, 1, CL_MEM_ONCHIP_GLOBAL_OFFSET_QCOM, offset_for_nv12_image, 0};
    buffer_circle_nv12 = clCreateBufferWithProperties(context, buffer_properties, CL_MEM_READ_WRITE | CL_MEM_HOST_NO_ACCESS, image_size_bytes_nv12, nullptr, &err);
    HANDLE_ERROR(err, "clCreateBufferWithProperties for backing buffer_circle_nv12\n");
    printf("\nAllocated onchip global memory for backing buffer for NV12 image (W%u, H%u):\nsize: %zu bytes\noffset: %zu bytes\n\n", image_width, image_height, image_size_bytes_nv12, image_size_bytes);

    nv12_desc.mem_object = buffer_circle_nv12;

    image_circle_nv12 = clCreateImage(context, CL_MEM_READ_ONLY, &nv12_format, &nv12_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImage for image_circle_nv12\n");

    // Images for Individual Planes
    cl_image_desc plane_desc = {};
    plane_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    plane_desc.image_width  = nv12_desc.image_width;
    plane_desc.image_height = nv12_desc.image_height;
    plane_desc.mem_object   = image_circle_nv12;

    // Y-Plane
    cl_image_format y_plane_format = {};
    y_plane_format.image_channel_order     = CL_QCOM_NV12_Y;
    y_plane_format.image_channel_data_type = CL_UNORM_INT8;

    image_circle_y_plane = clCreateImage(context, CL_MEM_WRITE_ONLY, &y_plane_format, &plane_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImage for image_circle_y_plane\n");

    // UV-Plane
    cl_image_format uv_plane_format = {};
    uv_plane_format.image_channel_order     = CL_QCOM_NV12_UV;
    uv_plane_format.image_channel_data_type = CL_UNORM_INT8;

    image_circle_uv_plane = clCreateImage(context, CL_MEM_WRITE_ONLY, &uv_plane_format, &plane_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImage for image_circle_uv_plane\n");


    /*
     * Create image and mem objects for the final output NV12 image.
     */

    cl_image_format nv12_format_output = {};
    nv12_format_output.image_channel_order = CL_QCOM_NV12;
    nv12_format_output.image_channel_data_type = CL_UNORM_INT8;

    cl_image_desc nv12_desc_output = {};
    nv12_desc_output.image_type = CL_MEM_OBJECT_IMAGE2D;
    nv12_desc_output.image_width = image_width;
    nv12_desc_output.image_height = image_height;

    out_nv12_mem = wrapper.make_buffer_for_yuv_image(nv12_format_output, nv12_desc_output);
    out_nv12_image = clCreateImage(
            context,
            CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR | CL_MEM_EXT_HOST_PTR_QCOM,
            &nv12_format_output,
            &nv12_desc_output,
            &out_nv12_mem,
            &err
    );
    HANDLE_ERROR(err, "clCreateImage for out_nv12_image\n");

    cl_image_format out_y_plane_format = {};
    out_y_plane_format.image_channel_order     = CL_QCOM_NV12_Y;
    out_y_plane_format.image_channel_data_type = CL_UNORM_INT8;

    cl_image_desc out_y_plane_desc = {};
    out_y_plane_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    out_y_plane_desc.image_width  = image_width;
    out_y_plane_desc.image_height = image_height;
    out_y_plane_desc.mem_object   = out_nv12_image;

    out_y_plane = clCreateImage(context, CL_MEM_WRITE_ONLY | CL_MEM_HOST_READ_ONLY, &out_y_plane_format, &out_y_plane_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImage for out_nv12_image y-plane\n");

    cl_image_format out_uv_plane_format = {};
    out_uv_plane_format.image_channel_order     = CL_QCOM_NV12_UV;
    out_uv_plane_format.image_channel_data_type = CL_UNORM_INT8;

    cl_image_desc out_uv_plane_desc = {};
    out_uv_plane_desc.image_type   = CL_MEM_OBJECT_IMAGE2D;
    out_uv_plane_desc.image_width  = image_width;
    out_uv_plane_desc.image_height = image_height;
    out_uv_plane_desc.mem_object   = out_nv12_image;

    out_uv_plane = clCreateImage(context, CL_MEM_WRITE_ONLY | CL_MEM_HOST_READ_ONLY, &out_uv_plane_format, &out_uv_plane_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImage for out_nv12_image uv-plane\n");

    /*
     * Start enqueuing kernels into a recordable queue so that the data in
     * onchip global memory is perserved between different kernel executions.
     */
    recordable_queue = clCreateCommandQueue(context, device_id, CL_QUEUE_RECORDABLE_QCOM, &err);
    HANDLE_ERROR(err, "clCreateCommandQueue: Failed to create command queue with CL_QUEUE_RECORDABLE_QCOM.\n");

    recording = clNewRecordingQCOM(recordable_queue, &err);
    HANDLE_ERROR(err, "clNewRecordingQCOM\n");

    /*
     * 1. Run a kernel which creates an image of a circle
     *    and stores it in onchip global memory.
     */
    err = clSetKernelArg(kernel_circle, 0, sizeof(image_circle_rgba), &image_circle_rgba);
    HANDLE_ERROR(err, "clSetKernelArg for argument 0 of kernel_circle.\n");
    err = clSetKernelArg(kernel_circle, 1, sizeof(circle_radius), &circle_radius);
    HANDLE_ERROR(err, "clSetKernelArg for argument 1 of kernel_circle.\n");
    err = clEnqueueNDRangeKernel(recordable_queue, kernel_circle, 2, nullptr, work_size, nullptr, 0, nullptr, nullptr);
    HANDLE_ERROR(err, "clEnqueueNDRangeKernel kernel_circle\n");

    /*
     * 2. Convert RGBA image of circle into NV12 and store it in onchip global memory.
     */
    err = clSetKernelArg(kernel_convert, 0, sizeof(image_circle_rgba), &image_circle_rgba);
    HANDLE_ERROR(err, "clSetKernelArg for argument 0 of kernel_convert.\n");
    err = clSetKernelArg(kernel_convert, 1, sizeof(image_circle_y_plane), &image_circle_y_plane);
    HANDLE_ERROR(err, "clSetKernelArg for argument 1 of kernel_convert.\n");
    err = clSetKernelArg(kernel_convert, 2, sizeof(image_circle_uv_plane), &image_circle_uv_plane);
    HANDLE_ERROR(err, "clSetKernelArg for argument 2 of kernel_convert.\n");
    const size_t work_size_rgba_to_nv12[] = {image_width / 2, image_height / 2};
    err = clEnqueueNDRangeKernel(recordable_queue, kernel_convert, 2, nullptr, work_size_rgba_to_nv12, nullptr, 0, nullptr, nullptr);
    HANDLE_ERROR(err, "clEnqueueNDRangeKernel kernel_convert\n");

    /*
     * 3. Apply blur to the NV12 circle image which is residing in onchip global memory
     *    and write the output to an NV12 image in normal global memory.
     */
    err = clSetKernelArg(kernel_blur, 0, sizeof(image_circle_nv12), &image_circle_nv12);
    HANDLE_ERROR(err, "clSetKernelArg for argument 0 of kernel_blur.\n");
    err = clSetKernelArg(kernel_blur, 1, sizeof(out_y_plane), &out_y_plane);
    HANDLE_ERROR(err, "clSetKernelArg for argument 1 of kernel_blur.\n");
    err = clSetKernelArg(kernel_blur, 2, sizeof(out_uv_plane), &out_uv_plane);
    HANDLE_ERROR(err, "clSetKernelArg for argument 2 of kernel_blur.\n");
    err = clEnqueueNDRangeKernel(recordable_queue, kernel_blur, 2, nullptr, work_size, nullptr, 0, nullptr, nullptr);
    HANDLE_ERROR(err, "clEnqueueNDRangeKernel kernel_blur\n");

    err = clEndRecordingQCOM(recording);
    HANDLE_ERROR(err, "clEndRecordingQCOM\n");

    err = clEnqueueRecordingQCOM(command_queue, recording,
                                 0, nullptr,
                                 0, nullptr,
                                 0, nullptr,
                                 0, nullptr,
                                 0, nullptr,
                                 nullptr);
    HANDLE_ERROR(err, "clEnqueueRecordingQCOM\n");

    err = clFinish(command_queue);
    HANDLE_ERROR(err, "clFinish for command_queue\n");

    /*
     * 4. Read the final blurred NV12 image into host memory from the normal global memory buffer.
     *    (Copy image data from device to host without row padding.)
     */

    size_t origin[3] = {0, 0, 0};
    size_t region_y[3] = {image_width, image_height, 1};
    size_t row_pitch = 0;
    unsigned char *image_ptr = nullptr;

    nv12_image_t out_nv12_image_info = {};
    out_nv12_image_info.y_width  = image_width;
    out_nv12_image_info.y_height = image_height;
    out_nv12_image_info.y_plane.resize(out_nv12_image_info.y_width * out_nv12_image_info.y_height);
    out_nv12_image_info.uv_plane.resize(out_nv12_image_info.y_width * out_nv12_image_info.y_height / 2);

    dma_buf_sync buf_sync = {};
    buf_sync.flags = DMA_BUF_SYNC_START | DMA_BUF_SYNC_READ;
    err = ioctl(out_nv12_mem.dmabuf_filedesc, DMA_BUF_IOCTL_SYNC, &buf_sync);
    HANDLE_ERROR(err, "ioctl for DMA buf sync start read\n")

    image_ptr = reinterpret_cast<unsigned char *>(clEnqueueMapImage(
            command_queue,
            out_y_plane,
            CL_BLOCKING,
            CL_MAP_READ,
            origin,
            region_y,
            &row_pitch,
            nullptr,
            0,
            nullptr,
            nullptr,
            &err
    ));
    HANDLE_ERROR(err, "clEnqueueMapImage for out_y_plane");

    for (uint32_t i = 0; i < out_nv12_image_info.y_height; ++i)
    {
        std::memcpy(
                out_nv12_image_info.y_plane.data() + i * out_nv12_image_info.y_width,
                image_ptr                          + i * row_pitch,
                out_nv12_image_info.y_width
        );
    }

    err = clEnqueueUnmapMemObject(command_queue, out_y_plane, image_ptr, 0, nullptr, nullptr);
    HANDLE_ERROR(err, "clEnqueueUnmapMemObject for y plane output\n");

    size_t region_uv[3] = {image_width / 2, image_height / 2, 1};

    image_ptr = reinterpret_cast<unsigned char *>(clEnqueueMapImage(
            command_queue,
            out_uv_plane,
            CL_BLOCKING,
            CL_MAP_READ,
            origin,
            region_uv,
            &row_pitch,
            nullptr,
            0,
            nullptr,
            nullptr,
            &err
    ));
    HANDLE_ERROR(err, "clEnqueueMapImage for out_uv_plane");

    for (uint32_t i = 0; i < out_nv12_image_info.y_height / 2; ++i)
    {
        std::memcpy(
                out_nv12_image_info.uv_plane.data() + i * out_nv12_image_info.y_width,
                image_ptr                           + i * row_pitch,
                out_nv12_image_info.y_width
        );
    }

    cl_event unmap_event;
    err = clEnqueueUnmapMemObject(command_queue, out_uv_plane, image_ptr, 0, nullptr, &unmap_event);
    HANDLE_ERROR(err, "clEnqueueUnmapMemObject for uv plane output\n");
    err = clWaitForEvents(1, &unmap_event);
    HANDLE_ERROR(err, "clWaitForEvents unmap_event for uv plane output\n")
    err = clReleaseEvent(unmap_event);
    HANDLE_ERROR(err, "clReleaseEvent unmap_event for uv plane output\n")

    buf_sync.flags = DMA_BUF_SYNC_END | DMA_BUF_SYNC_READ;
    err = ioctl(out_nv12_mem.dmabuf_filedesc, DMA_BUF_IOCTL_SYNC, &buf_sync);
    HANDLE_ERROR(err, "ioctl for DMA buf sync end read\n")

    save_nv12_image_data(output_file_name, out_nv12_image_info);
    printf("Output image written to %s\n", output_file_name.c_str());

    // Clean up OpenCL resources that aren't automatically handled by cl_wrapper.
    err = clReleaseMemObject(image_circle_rgba);
    HANDLE_ERROR(err, "clReleaseMemObject for image_circle_rgba\n");
    err = clReleaseMemObject(image_circle_uv_plane);
    HANDLE_ERROR(err, "clReleaseMemObject for image_circle_uv_plane\n");
    err = clReleaseMemObject(image_circle_y_plane);
    HANDLE_ERROR(err, "clReleaseMemObject for image_circle_y_plane\n");
    err = clReleaseMemObject(image_circle_nv12);
    HANDLE_ERROR(err, "clReleaseMemObject for image_circle_nv12\n");
    err = clReleaseMemObject(buffer_circle_nv12);
    HANDLE_ERROR(err, "clReleaseMemObject for buffer_circle_nv12\n");
    err = clReleaseMemObject(out_uv_plane);
    HANDLE_ERROR(err, "clReleaseMemObject for out_uv_plane\n");
    err = clReleaseMemObject(out_y_plane);
    HANDLE_ERROR(err, "clReleaseMemObject for out_y_plane\n");
    err = clReleaseMemObject(out_nv12_image);
    HANDLE_ERROR(err, "clReleaseMemObject for out_nv12_image\n");
    err = clReleaseRecordingQCOM(recording);
    HANDLE_ERROR(err, "clReleaseRecordingQCOM\n");
    err = clReleaseCommandQueue(recordable_queue);
    HANDLE_ERROR(err, "clReleaseCommandQueue for recordable_queue.\n");

    return EXIT_SUCCESS;
}
