//--------------------------------------------------------------------------------------
// File: onchip_global_memory_image_rgba.cpp
// Desc: Demonstrating usage of cl_qcom_onchip_global_memory for RGBA images
//
// Author:      QUALCOMM
//
//               Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

#include <string>
#include <cstdlib>

#include <CL/cl.h>
#include <CL/cl_ext_qcom.h>

#include "util/cl_wrapper.h"
#include "util/util.h"

/*
 * This sample shows how to create and use a non-planar image object in
 * onchip global memory.
 *
 * 1. Kernel "draw_circle" generates an image of a circle in RGBA
 *    format in onchip global memory.
 *
 * 2. Kernel "blur" then applies a blur to the RGBA image generated
 *    in the previous step and writes it to normal global memory.
 *
 * 3. The final RGBA image data is then read from this normal global
 *    memory into host memory and written to a file.
 *
 */

static const char *PROGRAM_SOURCE = R"(
    __constant sampler_t sampler = CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE | CLK_FILTER_NEAREST;
    __constant float4 circle_color = (float4) (0.859f, 0.196f, 0.212f, 1.0f);
    __constant float4 background_color = (float4) (0.961f, 0.961f, 0.863f, 1.0f);

    __kernel void draw_circle(__write_only image2d_t image, int radius)
    {
        const uint size_x = get_global_size(0);
        const uint size_y = get_global_size(1);

        const int x = get_global_id(0);
        const int y = get_global_id(1);

        const int xt = x - (size_x / 2);
        const int yt = y - (size_y / 2);

        if(((xt * xt) + (yt * yt)) < (radius * radius))
        {
            write_imagef(image, (int2)(x, y), circle_color);
        }
        else
        {
            write_imagef(image, (int2)(x, y), background_color);
        }
    }

    __kernel void blur(__read_only image2d_t image_in, __write_only image2d_t image_out)
    {
        const uint size_x = get_global_size(0);
        const uint size_y = get_global_size(1);

        const int x = get_global_id(0);
        const int y = get_global_id(1);

        const int blur_size = 20;

        float4 pix;

        float4 out = (float4)(0, 0, 0, 0);
        for(int i = (x - blur_size); i < (x + blur_size); i++) {
            for(int j = (y - blur_size); j < (y + blur_size); j++) {
                if(i < 0 || j < 0 || i >= size_x || j >= size_y) {
                    pix = background_color;
                }
                else {
                    pix = read_imagef(image_in, sampler, (int2)(i, j));
                }
                out += pix;
            }
        }
        out /= (2 * 2 * blur_size * blur_size);

        write_imagef(image_out, (int2)(x, y), out);
    }
)";

static const cl_int  circle_radius = 70;
static const cl_uint image_width   = 400;
static const cl_uint image_height  = 400;

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        printf("Usage: %s <Output Image File Name>\n", argv[0]);
        return EXIT_FAILURE;
    }

    std::string output_file_name = argv[1];

    cl_int err = CL_SUCCESS;

    cl_wrapper          wrapper;
    cl_program          program       = wrapper.make_program(&PROGRAM_SOURCE, 1);
    cl_kernel           kernel_circle = wrapper.make_kernel("draw_circle", program);
    cl_kernel           kernel_blur   = wrapper.make_kernel("blur", program);
    cl_device_id        device_id     = wrapper.get_device_id();
    cl_context          context       = wrapper.get_context();
    cl_command_queue    command_queue = wrapper.get_command_queue();

    cl_command_queue  recordable_queue;
    cl_recording_qcom recording;

    // Mem object for the RGBA image in onchip global memory
    cl_mem image_circle;

    // Mem object for the output blurred image in normal global memory
    cl_mem image_blurred;

    size_t  image_size_bytes = image_width * image_height * sizeof(cl_uchar4);
    size_t  work_size[]      = {image_width, image_height};

    /*
     * Confirm the required OpenCL extensions are supported.
     */
    HANDLE_ERROR(!wrapper.check_extensions_support({
        "cl_qcom_onchip_global_memory",
        "cl_qcom_recordable_queues", // recordable queues are used to retain content of onchip global memory between kernels
    }), "\nOne or more extensions needed for this sample are not supported on this device\nExiting..\n");

    size_t available_onchip_global_memory;
    err = clGetDeviceInfo(device_id, CL_DEVICE_ONCHIP_GLOBAL_MEM_SIZE_QCOM, sizeof(available_onchip_global_memory), &available_onchip_global_memory, nullptr);
    HANDLE_ERROR(err, "clGetDeviceInfo [CL_DEVICE_ONCHIP_GLOBAL_MEM_SIZE_QCOM]\n");
    printf("Available onchip global memory: %zu\n", available_onchip_global_memory);

    /*
     * Create image object for the RGBA image in onchip global memory.
     */

    cl_image_format image_format = {};
    image_format.image_channel_order = CL_RGBA;
    image_format.image_channel_data_type = CL_UNORM_INT8;

    cl_image_desc image_desc = {};
    image_desc.image_type = CL_MEM_OBJECT_IMAGE2D;
    image_desc.image_width = image_width;
    image_desc.image_height = image_height;

    cl_mem_properties image_circle_properties[5] = {CL_MEM_ONCHIP_GLOBAL_QCOM, 1, CL_MEM_ONCHIP_GLOBAL_OFFSET_QCOM, 0, 0};
    image_circle = clCreateImageWithProperties(context, image_circle_properties, CL_MEM_READ_WRITE | CL_MEM_HOST_NO_ACCESS, &image_format, &image_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImageWithProperties [CL_MEM_ONCHIP_GLOBAL_QCOM] for image_circle at offset: %u of size %zu.\n", 0, image_size_bytes);
    printf("\nAllocated onchip global memory for RGBA image (W%u, H%u):\nsize: %zu\noffset: %u\n\n", image_width, image_height, image_size_bytes, 0);

    /*
     * Create image object for the output blurred image in normal global memory.
     */
    image_blurred = clCreateImageWithProperties(context, nullptr, CL_MEM_WRITE_ONLY | CL_MEM_HOST_READ_ONLY, &image_format, &image_desc, nullptr, &err);
    HANDLE_ERROR(err, "clCreateImageWithProperties for image_blurred.\n");

    /*
     * Start enqueuing kernels into a recordable queue so that the data in
     * onchip global memory is perserved between different kernel executions.
     */
    recordable_queue = clCreateCommandQueue(context, device_id, CL_QUEUE_RECORDABLE_QCOM, &err);
    HANDLE_ERROR(err, "clCreateCommandQueue: Failed to create command queue with CL_QUEUE_RECORDABLE_QCOM.\n");

    recording = clNewRecordingQCOM(recordable_queue, &err);
    HANDLE_ERROR(err, "clNewRecordingQCOM\n");

    /*
     * 1. Run a kernel which creates an image of a circle
     *    and stores it in onchip global memory.
     */
    err = clSetKernelArg(kernel_circle, 0, sizeof(image_circle), &image_circle);
    HANDLE_ERROR(err, "clSetKernelArg for argument 0 of kernel_circle.\n");
    err = clSetKernelArg(kernel_circle, 1, sizeof(circle_radius), &circle_radius);
    HANDLE_ERROR(err, "clSetKernelArg for argument 1 of kernel_circle.\n");
    err = clEnqueueNDRangeKernel(recordable_queue, kernel_circle, 2, nullptr, work_size, nullptr, 0, nullptr, nullptr);
    HANDLE_ERROR(err, "clEnqueueNDRangeKernel kernel_circle\n");

    /*
     * 2. Apply blur to the circle image which is residing in onchip global memory
     *    and write out the final pixel values to normal global memory.
     */
    err = clSetKernelArg(kernel_blur, 0, sizeof(image_circle), &image_circle);
    HANDLE_ERROR(err, "clSetKernelArg for argument 0 of kernel_blur.\n");
    err = clSetKernelArg(kernel_blur, 1, sizeof(image_blurred), &image_blurred);
    HANDLE_ERROR(err, "clSetKernelArg for argument 1 of kernel_blur.\n");
    err = clEnqueueNDRangeKernel(recordable_queue, kernel_blur, 2, nullptr, work_size, nullptr, 0, nullptr, nullptr);
    HANDLE_ERROR(err, "clEnqueueNDRangeKernel kernel_blur\n");

    err = clEndRecordingQCOM(recording);
    HANDLE_ERROR(err, "clEndRecordingQCOM\n");

    err = clEnqueueRecordingQCOM(command_queue, recording,
                                 0, nullptr,
                                 0, nullptr,
                                 0, nullptr,
                                 0, nullptr,
                                 0, nullptr,
                                 nullptr);
    HANDLE_ERROR(err, "clEnqueueRecordingQCOM\n");

    /*
     * 3. Read the final blurred image into host memory from the normal
     *    global memory buffer and write to file.
     */

    rgba_image_t out_rgba_image_info = {};
    out_rgba_image_info.width  = image_width;
    out_rgba_image_info.height = image_height;
    out_rgba_image_info.pixels.resize(image_size_bytes);

    size_t origin[3] = {0, 0, 0};
    size_t region[3] = {image_width, image_height, 1};
    err = clEnqueueReadImage(command_queue, image_blurred, CL_BLOCKING, origin, region, image_width * 4, 0, out_rgba_image_info.pixels.data(), 0, nullptr, nullptr);
    HANDLE_ERROR(err, "clEnqueueReadImage for image_blurred");

    save_rgba_image_data(output_file_name, out_rgba_image_info);
    printf("Output image written to %s\n", output_file_name.c_str());

    // Clean up OpenCL resources that aren't automatically handled by cl_wrapper.
    err = clReleaseMemObject(image_circle);
    HANDLE_ERROR(err, "clReleaseMemObject for image_circle.\n");
    err = clReleaseMemObject(image_blurred);
    HANDLE_ERROR(err, "clReleaseMemObject for image_blurred.\n");
    err = clReleaseRecordingQCOM(recording);
    HANDLE_ERROR(err, "clReleaseRecordingQCOM\n");
    err = clReleaseCommandQueue(recordable_queue);
    HANDLE_ERROR(err, "clReleaseCommandQueue for recordable_queue.\n");

    return EXIT_SUCCESS;
}
