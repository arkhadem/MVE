//--------------------------------------------------------------------------------------
// File: qcom_bfloat16_product_image.cpp
// Desc: This example demonstrates the usage of cl_qcom_bfloat16_product using images
//
// These are 2 different scenarios covered here:
//      1. Bfloat16 is intermediate format for compute.
//         Next stage requires blfoat16.
//      2. Bfloat16 is intermediate format for compute.
//         Is the last stage, FP32 is required to write image.
//
// Author:      QUALCOMM
//
//          Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <vector>
#include <CL/cl.h>
#include "util/cl_wrapper.h"

static const char* PROGRAM_SOURCE = R"(

    #pragma OPENCL EXTENSION cl_qcom_bfloat16_product : enable
    #pragma OPENCL EXTENSION cl_khr_fp16 : enable

    // Kernel showing bf16 using image types with cl_channel_type set to CL_HALF_FLOAT
    // First 3 parameters correspond to parameters to the qcom_mad32_bf16 instruction and the
    // last parameter is the output
    __kernel void img_op_bf16(__read_only image1d_t src0, __read_only image1d_t src1,  __read_only image1d_t src2,  __write_only image1d_t out)
    {
        const sampler_t nearest_sampler = CLK_NORMALIZED_COORDS_FALSE |
                                          CLK_ADDRESS_CLAMP_TO_EDGE   |
                                          CLK_FILTER_NEAREST;

        int x = get_global_id(0);
        half4 src0_pix = read_imageh(src0, nearest_sampler, x);
        half4 src1_pix = read_imageh(src1, nearest_sampler, x);
        float4 src2_pix = read_imagef(src2, nearest_sampler, x);
        float out_fp32 = qcom_mad32_bf16(as_ushort(src0_pix.x), as_ushort(src1_pix.x), src2_pix.x);
        ushort out_bf16 = as_uint(out_fp32) >> 16;      //Removing the least significant 16 bits from float to make bfloat16
        write_imageh(out, x, (half4)(as_half(out_bf16), 0.0, 0.0, 0.0));
    }

    // Kernel showing bf16 using image types with cl_channel_type set to CL_HALF_FLOAT
    // First 3 parameters correspond to parameters to the qcom_mad32_bf16 instruction and the
    // last parameter is the output
    __kernel void img_op_fp32(__read_only image1d_t src0, __read_only image1d_t src1,  __read_only image1d_t src2,  __write_only image1d_t out)
    {
        const sampler_t nearest_sampler = CLK_NORMALIZED_COORDS_FALSE |
                                          CLK_ADDRESS_CLAMP_TO_EDGE   |
                                          CLK_FILTER_NEAREST;

        int x = get_global_id(0);
        half4 src0_pix = read_imageh(src0, nearest_sampler, x);
        half4 src1_pix = read_imageh(src1, nearest_sampler, x);
        float4 src2_pix = read_imagef(src2, nearest_sampler, x);
        float out_fp32 = qcom_mad32_bf16(as_ushort(src0_pix.x), as_ushort(src1_pix.x), src2_pix.x);
        write_imagef(out, x, (float4)(out_fp32, 0.0, 0.0, 0.0));
    }
)";

inline cl_ushort float_to_bf16_ushort(float f)
{
    return static_cast<cl_ushort>( *( reinterpret_cast<uint32_t*>(&f) ) >> 16 );
}

inline float bf16_ushort_to_float(cl_ushort s)
{
    uint32_t i = (static_cast<uint32_t>(s) << 16);
    return *(reinterpret_cast<float *>(&i));
}

bool is_nan_or_inf(cl_float f)
{
    return isnan(f) || isinf(f);
}

inline void cl_err_check(cl_int &err, const char * file, const unsigned int line, const char* fmt...)
{
    va_list args;
    const size_t mesg_size = 100;   //Assumes message size
    char mesg[mesg_size];

    if (err != CL_SUCCESS)
    {
        va_start(args, fmt);
        vsnprintf(mesg, mesg_size, fmt, args);
        va_end(args);

        fprintf(stderr, "%s:%d  %s" , file, line, mesg);

        exit(static_cast<int>(err));
    }
}

inline void print_results(size_t i, cl_ushort src0_ref, cl_ushort src1_ref, cl_float src2_ref,
                          cl_float output, size_t &undefined)
{
    if (is_nan_or_inf(bf16_ushort_to_float(src0_ref))
        || is_nan_or_inf(bf16_ushort_to_float(src1_ref))
        || is_nan_or_inf(src2_ref)
        || is_nan_or_inf(output))
    {
        std::cerr << "NaN or Inf at input " << i << "\n";
        ++undefined;
        return;
    }

    std::cout << "Input " << i
              << " s0: " << bf16_ushort_to_float(src0_ref)
              << " s1: " << bf16_ushort_to_float(src1_ref)
              << " s2: " << src2_ref
              << " result: " << output << "\n";
}

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        std::cerr << "Usage: " << argv[0] << " <option>\n"
                                             "\t<option> = bf16 | fp32\n";
        return EXIT_FAILURE;
    }

    if(strcmp(argv[1],"bf16") != 0
    && strcmp(argv[1],"fp32") != 0)
    {
        std::cerr << "Usage: " << argv[0] << " <option>\n"
                                             "\t<option> = bf16 | fp32\n";
        return EXIT_FAILURE;
    }

    cl_wrapper         wrapper;
    cl_device_id       device        = wrapper.get_device_id();
    cl_program         program       = wrapper.make_program(&PROGRAM_SOURCE, 1, "-cl-std=CL3.0");
    cl_kernel          kernel;
    cl_context         context       = wrapper.get_context();
    cl_command_queue   command_queue = wrapper.get_command_queue();
    cl_int             err           = CL_SUCCESS;
    bool               isBF16        = strcmp(argv[1], "bf16") == 0;

    if(isBF16){
        kernel = wrapper.make_kernel("img_op_bf16", program);
    }
    else{
        kernel = wrapper.make_kernel("img_op_fp32", program);
    }

    // Setup example
    size_t undefined = 0;

    static const size_t work_items = 128;                   //Sample width
    std::vector<cl_ushort> src0_ref(work_items,0);
    std::vector<cl_ushort> src1_ref(work_items,0);
    std::vector<cl_float> src2_ref(work_items,0.0f);


    cl_image_desc image_desc = {CL_MEM_OBJECT_IMAGE1D, work_items, 1};
    cl_image_format bf16_image_format = {CL_R, CL_HALF_FLOAT};
    cl_image_format fp32_image_format = {CL_R, CL_FLOAT};
    size_t image_size = 0;

    //For imageBF16
    cl_ushort *hostmapBF16;

    //For imageFP32
    cl_float *hostmapFP32;

    /*
     * Sample values:
     * src0[] = 1.0, 2.0, 3.0...
     * src1[] = 1.0, 2.0, 3.0...
     * src2[] = 1.0, 1.0, 1.0...
    */
    for(unsigned int i = 0; i < work_items; ++i)
    {
        src0_ref[i] = float_to_bf16_ushort(static_cast<float>(i+1));
        src1_ref[i] = src0_ref[i];
        src2_ref[i] = 1.0f;
    }

    /*
     * Confirm the required OpenCL extensions are supported.
    */
    if (!wrapper.check_extension_support("cl_qcom_bfloat16_product"))
    {
        std::cerr << "cl_qcom_bfloat16_product extension is not supported.\n";
        return EXIT_FAILURE;
    }


    /*
     * Allocate device memory
     */

    cl_image_format *result_type;
    if(isBF16){
        result_type = &bf16_image_format;
    }
    else{
        result_type = &fp32_image_format;
    }

    cl_mem src0 = clCreateImage(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, &bf16_image_format, &image_desc, src0_ref.data(), &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateImage for src0.\n", err);

    cl_mem src1 = clCreateImage(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, &bf16_image_format, &image_desc, src1_ref.data(), &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateImage for src1.\n", err);

    cl_mem src2 = clCreateImage(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, &fp32_image_format, &image_desc, src2_ref.data(), &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateImage for src2.\n", err);

    cl_mem result = clCreateImage(context, CL_MEM_HOST_READ_ONLY | CL_MEM_WRITE_ONLY, result_type, &image_desc, nullptr, &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateImage for result.\n", err);

    /*
     * Set kernel arguments
     */
    err = clSetKernelArg(kernel, 0, sizeof(src0), &src0);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 0.\n", err);

    err = clSetKernelArg(kernel, 1, sizeof (src1), &src1);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 1.\n", err);

    err = clSetKernelArg(kernel, 2, sizeof(src2), &src2);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 2.\n", err);

    err = clSetKernelArg(kernel, 3, sizeof(result), &result);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 3.\n", err);

    /*
     * Launch kernel
     */
    static const size_t global_work_size[3] = {image_desc.image_width, 0, 0};
    err = clEnqueueNDRangeKernel(
            command_queue,
            kernel,
            1,                      // work dimension of input buffer
            nullptr,
            global_work_size,
            nullptr,
            0,
            nullptr,
            nullptr
    );
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clEnqueueNDRangeKernel.\n", err);

    err = clFinish(command_queue);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while finishing the command queue.\n", err);

    size_t origin[]         = {0,0,0};
    size_t region[]         = {image_desc.image_width, image_desc.image_height, 1};

    /*
     * Read from buffer
     */

    err = clQueryImageInfoQCOM(
            device,CL_MEM_READ_WRITE,
            result_type,
            &image_desc,
            CL_IMAGE_SIZE_QCOM,
            sizeof(size_t),
            &image_size,
            nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while running clQueryImageInfoQCOM.\n", err);

    void *host_map;
    if(isBF16){
        hostmapBF16 = new cl_ushort[image_size/sizeof(cl_ushort)];
        host_map = static_cast<void *>(hostmapBF16);
    }
    else{
        hostmapFP32 = new cl_float[image_size/sizeof(cl_float)];
        host_map = static_cast<void *>(hostmapFP32);
    }

    err = clEnqueueReadImage(
            command_queue,result,
            CL_BLOCKING,                //Extra precaution, can be CL_NON_BLOCKING. Necessary if clFinish were removed.
            origin, region, 0, 0,
            host_map,0,
            nullptr,nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while running clEnqueueReadImage.\n", err);

    if(isBF16){
        for (size_t i = 0; i < image_desc.image_width; ++i){
            float output = bf16_ushort_to_float(hostmapBF16[i]);
            print_results(i, src0_ref[i], src1_ref[i], src2_ref[i], output, undefined);
        }
    }
    else{
        for (size_t i = 0; i < image_desc.image_width; ++i){
            print_results(i, src0_ref[i], src1_ref[i], src2_ref[i], hostmapFP32[i], undefined);
        }
    }

    if(undefined){
        std::cout<< undefined << " out of " << work_items << " are NaNs or Inf.\n";
    }

    /*
     * Cleanup
     */

    if(isBF16){
        delete []hostmapBF16;
    }
    else{
        delete []hostmapFP32;
    }

    err = clReleaseMemObject(result);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing result.\n", err);

    err = clReleaseMemObject(src0);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing src0.\n", err);

    err = clReleaseMemObject(src1);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing src1.\n", err);

    err = clReleaseMemObject(src2);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing src2.\n", err);

    return EXIT_SUCCESS;
}
