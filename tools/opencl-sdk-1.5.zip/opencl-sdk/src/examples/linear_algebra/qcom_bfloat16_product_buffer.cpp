//--------------------------------------------------------------------------------------
// File: qcom_bfloat16_product_buffer.cpp
// Desc: This example demonstrates the usage of cl_qcom_bfloat16_product using buffers
//
// These are 2 different scenarios covered here:
//      1. Bfloat16 is intermediate format for compute.
//         Next stage requires blfoat16.
//      2. Bfloat16 is intermediate format for compute.
//         Is the last stage, FP32 is the final output format.
//
// Author:      QUALCOMM
//
//          Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <vector>
#include <CL/cl.h>
#include "util/cl_wrapper.h"

static const char* PROGRAM_SOURCE = R"(

    #pragma OPENCL EXTENSION cl_qcom_bfloat16_product : enable
    #pragma OPENCL EXTENSION cl_khr_fp16 : enable

    // First 3 parameters correspond to parameters to the qcom_mad32_bf16 instruction and the
    // last parameter is the output
    __kernel void buff_op_fp32(__global ushort* src0, __global ushort* src1, __global float* src2, __global float* out)
    {
        size_t i = get_global_id(0);
        out[i] = qcom_mad32_bf16(src0[i], src1[i], src2[i]);
    }

    // Kernel with bf16 input and output representing typical usecase
    // First 3 parameters correspond to parameters to the qcom_mad32_bf16 instruction and the
    // last parameter is the output
    __kernel void buff_op_bf16(__global ushort* src0, __global ushort* src1, __global float* src2, __global ushort* out)
    {
        size_t i = get_global_id(0);
        float op = qcom_mad32_bf16(src0[i], src1[i], src2[i]);
        out[i] = as_uint(op) >> 16;                //Removing the least significant 16 bits from float to make bfloat16
    }

)";

inline cl_ushort float_to_bf16_ushort(float f)
{
    return static_cast<cl_ushort>( *( reinterpret_cast<uint32_t*>(&f) ) >> 16 );
}

inline float bf16_ushort_to_float(cl_ushort s)
{
    uint32_t i = (static_cast<uint32_t>(s) << 16);
    return *(reinterpret_cast<float *>(&i));
}

bool is_nan_or_inf(cl_float f)
{
    return isnan(f) || isinf(f);
}

inline void cl_err_check(cl_int &err, const char * file, const unsigned int line, const char* fmt...)
{
    va_list args;
    const size_t mesg_size = 100;   //Assumes message size
    char mesg[mesg_size];

    if (err != CL_SUCCESS)
    {
        va_start(args, fmt);
        vsnprintf(mesg, mesg_size, fmt, args);
        va_end(args);

        fprintf(stderr, "%s:%d  %s" , file, line, mesg);

        exit(static_cast<int>(err));
    }
}

inline void print_results(size_t i, cl_ushort src0_ref, cl_ushort src1_ref, cl_float src2_ref,
                          cl_float output, size_t &undefined)
{
    if (is_nan_or_inf(bf16_ushort_to_float(src0_ref))
        || is_nan_or_inf(bf16_ushort_to_float(src1_ref))
        || is_nan_or_inf(src2_ref)
        || is_nan_or_inf(output))
    {
        std::cerr << "NaN or Inf at input " << i << "\n";
        ++undefined;
        return;
    }

    std::cout << "Input " << i
              << " s0: " << bf16_ushort_to_float(src0_ref)
              << " s1: " << bf16_ushort_to_float(src1_ref)
              << " s2: " << src2_ref
              << " result: " << output << "\n";
}

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        std::cerr << "Usage: " << argv[0] << " <option>\n"
                                             "\t<option> = bf16 | fp32\n";
        return EXIT_FAILURE;
    }

    if(strcmp(argv[1],"bf16") != 0
    && strcmp(argv[1],"fp32") != 0)
    {
        std::cerr << "Usage: " << argv[0] << " <option>\n"
                                             "\t<option> = bf16 | fp32\n";
        return EXIT_FAILURE;
    }

    cl_wrapper         wrapper;
    cl_program         program       = wrapper.make_program(&PROGRAM_SOURCE, 1, "-cl-std=CL3.0");
    cl_kernel          kernel;
    cl_context         context       = wrapper.get_context();
    cl_command_queue   command_queue = wrapper.get_command_queue();
    cl_int             err           = CL_SUCCESS;
    bool               isBF16        = strcmp(argv[1], "bf16") == 0;

    if(isBF16){
        kernel = wrapper.make_kernel("buff_op_bf16", program);
    }
    else{
        kernel = wrapper.make_kernel("buff_op_fp32", program);
    }

    // Setup example
    size_t undefined = 0;

    static const size_t work_items = 128;                   //Sample width
    std::vector<cl_ushort> src0_ref(work_items,0);
    std::vector<cl_ushort> src1_ref(work_items,0);
    std::vector<cl_float> src2_ref(work_items,0.0f);

    size_t typeWidth = ((isBF16) ? sizeof(cl_ushort) : sizeof(cl_float));

    //For bufferBF16
    std::vector<cl_ushort> hostmapBF16(work_items,0);

    //For bufferFP32
    std::vector<cl_float> hostmapFP32(work_items,0.0f);

    /*
     * Sample values:
     * src0[] = 1.0, 2.0, 3.0...
     * src1[] = 1.0, 2.0, 3.0...
     * src2[] = 1.0, 1.0, 1.0...
    */
    for(size_t i = 0; i < work_items; ++i)
    {
        src0_ref[i] = float_to_bf16_ushort(static_cast<float>(i+1));
        src1_ref[i] = src0_ref[i];
        src2_ref[i] = 1.0f;
    }

    /*
     * Confirm the required OpenCL extensions are supported.
    */
    if (!wrapper.check_extension_support("cl_qcom_bfloat16_product"))
    {
        std::cerr << "cl_qcom_bfloat16_product extension is not supported.\n";
        return EXIT_FAILURE;
    }


    /*
     * Allocate device memory
     */
    cl_mem result = clCreateBuffer(context,
                                   CL_MEM_HOST_READ_ONLY | CL_MEM_WRITE_ONLY,
                                   work_items * typeWidth,
                                   nullptr,
                                   &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateBuffer for result.\n", err);

    cl_mem src0 = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, work_items * sizeof(cl_ushort), &src0_ref[0], &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateBuffer for src0.\n", err);

    cl_mem src1 = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, work_items * sizeof(cl_ushort), &src1_ref[0], &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateBuffer for src1.\n", err);

    cl_mem src2 = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, work_items * sizeof(cl_float), &src2_ref[0], &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clCreateBuffer for src2.\n", err);


    /*
     * Set kernel arguments
     */
    err = clSetKernelArg(kernel, 0, sizeof(src0), &src0);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 0.\n", err);

    err = clSetKernelArg(kernel, 1, sizeof (src1), &src1);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 1.\n", err);

    err = clSetKernelArg(kernel, 2, sizeof(src2), &src2);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 2.\n", err);

    err = clSetKernelArg(kernel, 3, sizeof(result), &result);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 3.\n", err);


    /*
     * Launch kernel
     */
    static const size_t global_work_size = work_items;
    err = clEnqueueNDRangeKernel(
            command_queue,
            kernel,
            1,                      // work dimension of input buffer
            nullptr,
            &global_work_size,
            nullptr,
            0,
            nullptr,
            nullptr
    );
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clEnqueueNDRangeKernel.\n", err);

    err = clFinish(command_queue);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while finishing the command queue.\n", err);


    /*
     * Read from buffer
     */
    void * host_map;
    if(isBF16){
        host_map = &hostmapBF16[0];
    }
    else{
        host_map = &hostmapFP32[0];
    }
    err = clEnqueueReadBuffer(command_queue,
                        result,
                        CL_BLOCKING,    //Extra precaution, can be CL_NON_BLOCKING. Necessary if clFinish were removed.
                        0,
                        work_items * typeWidth,
                        host_map,
                        0,
                        nullptr,
                        nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while mapping output buffer.\n", err);


    /*
     * Print results
     */
    if(isBF16){
        for (size_t i = 0; i < work_items; ++i){
            float output = bf16_ushort_to_float(hostmapBF16[i]);
            print_results(i, src0_ref[i], src1_ref[i], src2_ref[i], output, undefined);
        }
    }
    else{
        for (size_t i = 0; i < work_items; ++i){
            print_results(i, src0_ref[i], src1_ref[i], src2_ref[i], hostmapFP32[i], undefined);
        }
    }

    if(undefined){
        std::cout<< undefined << " out of " << work_items << " are NaNs or Inf.\n";
    }

    /*
     * Cleanup
     */
    err = clReleaseMemObject(result);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing result.\n", err);

    err = clReleaseMemObject(src0);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing src0.\n", err);

    err = clReleaseMemObject(src1);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing src1.\n", err);

    err = clReleaseMemObject(src2);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing src2.\n", err);

    return EXIT_SUCCESS;
}
