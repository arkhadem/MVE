//--------------------------------------------------------------------------------------
// File: khr_integer_dot_product_unpacked.cpp
// Desc: This example demonstrates the usage of cl_khr_integer_dot_product
//
// Author:      QUALCOMM
//
//          Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

#include <cstdlib>
#include <iostream>
#include <vector>
#include <CL/cl.h>
#include "util/cl_wrapper.h"

static const char *PROGRAM_SOURCE = R"(
    __kernel void dot_acc_sat_uu(
                  __global uint *res,
                  __global uchar4 *p0,
                  __global uchar4 *p1,
                  __global uint *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat(p0[i], p1[i], acc[i]);
    }

    __kernel void dot_acc_sat_su(
                  __global int *res,
                  __global char4 *p0,
                  __global uchar4 *p1,
                  __global int *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat(p0[i], p1[i], acc[i]);
    }

    __kernel void dot_acc_sat_us(
                  __global int *res,
                  __global uchar4 *p0,
                  __global char4 *p1,
                  __global int *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat(p0[i], p1[i], acc[i]);
    }

    __kernel void dot_acc_sat_ss(
                  __global int *res,
                  __global char4 *p0,
                  __global char4 *p1,
                  __global int *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat(p0[i], p1[i], acc[i]);
    }
)";

template <typename SrcT>
void set_values(SrcT &p, cl_uchar x, cl_uchar y, cl_uchar z, cl_uchar w, bool isSigned)
{
    if(isSigned)
    {
        p.x = static_cast<cl_char>(x);
        p.y = static_cast<cl_char>(y);
        p.z = static_cast<cl_char>(z);
        p.w = static_cast<cl_char>(w);
    }
    else
    {
        p.x = x;
        p.y = y;
        p.z = z;
        p.w = w;
    }
}

int saturated_add(int a, int b)
{
    if (a > 0 && b > INT32_MAX - a)
    {
        return INT32_MAX;
    }
    else if (a < 0 && b < INT32_MIN - a)
    {
        return INT32_MIN;
    }
    return a + b;
}

uint saturated_add(uint a, uint b)
{
    if(b > UINT32_MAX - a)
    {
        return UINT32_MAX;
    }
    return a + b;
}

template <typename Src1T, typename Src2T, typename DestT>
DestT dot_acc_sat(Src1T p0, Src2T p1, DestT acc)
{
    DestT dot_product = p0.x * p1.x + p0.y * p1.y + p0.z * p1.z + p0.w * p1.w;

    return saturated_add(dot_product, acc);
}

int main(int argc, char** argv)
{
    if (argc != 3)
    {
        std::cerr << "Usage: " << argv[0] << " <sign1> <sign2>\n"
                     "\t<sign1> = signed | unsigned\n"
                     "\t<sign2> = signed | unsigned\n";
        return EXIT_FAILURE;
    }

    if((strcmp(argv[1], "signed") != 0 && strcmp(argv[1], "unsigned") != 0)
    || (strcmp(argv[2], "signed") != 0 && strcmp(argv[2], "unsigned") != 0))
    {
        std::cerr << "Usage: " << argv[0] << " <sign1> <sign2>\n"
                     "\t<sign1> = signed | unsigned\n"
                     "\t<sign2> = signed | unsigned\n";
        return EXIT_FAILURE;
    }

    bool isSigned0 = strcmp(argv[1], "signed") == 0;
    bool isSigned1 = strcmp(argv[2], "signed") == 0;

    cl_wrapper         wrapper;
    cl_program         program       = wrapper.make_program(&PROGRAM_SOURCE, 1, "-cl-std=CL3.0");
    cl_kernel          kernel;
    cl_context         context       = wrapper.get_context();
    cl_command_queue   command_queue = wrapper.get_command_queue();
    cl_int             err           = CL_SUCCESS;

    if(isSigned0 && isSigned1)
    {
        kernel = wrapper.make_kernel("dot_acc_sat_ss", program);
    }
    else if(isSigned0 && !isSigned1)
    {
        kernel = wrapper.make_kernel("dot_acc_sat_su", program);
    }
    else if(!isSigned0 && isSigned1)
    {
        kernel = wrapper.make_kernel("dot_acc_sat_us", program);
    }
    else
    {
        kernel = wrapper.make_kernel("dot_acc_sat_uu", program);
    }

    // Setup example
    cl_uchar4 uc_p0, uc_p1;
    cl_char4 sc_p0, sc_p1;
    cl_uint uacc;
    cl_int sacc;

    if(isSigned0)
    {
        set_values(sc_p0, -11, 22, -33, 44, isSigned0);
        std::cout << "Signed input 0: sc_p0.x: " << static_cast<signed>(sc_p0.x) <<
                  ", sc_p0.y: " << static_cast<signed>(sc_p0.y) <<
                  ", sc_p0.z: " << static_cast<signed>(sc_p0.z) <<
                  ", sc_p0.w: " << static_cast<signed>(sc_p0.w) << "\n";
    }
    else
    {
        set_values(uc_p0, 11, 22, 33, 44, isSigned0);
        std::cout << "Unsigned input 0: uc_p0.x: "<< static_cast<unsigned>(uc_p0.x) <<
                  ", uc_p0.y: " << static_cast<unsigned>(uc_p0.y) <<
                  ", uc_p0.z: " << static_cast<unsigned>(uc_p0.z) <<
                  ", uc_p0.w: " << static_cast<unsigned>(uc_p0.w) << "\n";
    }
    if(isSigned1)
    {
        set_values(sc_p1, 55, -66, 77, -88, isSigned1);
        std::cout << "Signed input 1: sc_p1.x: " << static_cast<signed>(sc_p1.x) <<
                  ", sc_p1.y: " << static_cast<signed>(sc_p1.y) <<
                  ", sc_p1.z: " << static_cast<signed>(sc_p1.z) <<
                  ", sc_p1.w: " << static_cast<signed>(sc_p1.w) << std::endl;
    }
    else
    {
        set_values(uc_p1, 55, 66, 77, 88, isSigned1);
        std::cout << "Unsigned input 1: uc_p1.x: " << static_cast<unsigned>(uc_p1.x) <<
                  ", uc_p1.y: " << static_cast<unsigned>(uc_p1.y) <<
                  ", uc_p1.z: " << static_cast<unsigned>(uc_p1.z) <<
                  ", uc_p1.w: " << static_cast<unsigned>(uc_p1.w) << std::endl;
    }
    sacc= (isSigned0 || isSigned1)? -9 : 9;
    uacc= static_cast<cl_uint>(sacc);

    std::cout << "acc: " << sacc << std::endl;

    /*
     * Confirm the required OpenCL extensions are supported.
     */
    if (!wrapper.check_extension_support("cl_khr_integer_dot_product"))
    {
        std::cerr << "cl_khr_integer_dot_product extension is not supported.\n";
        return EXIT_FAILURE;
    }

    /*
     * Allocate device memory
     */
    cl_mem res_mem = clCreateBuffer(context,CL_MEM_HOST_READ_ONLY | CL_MEM_WRITE_ONLY, sizeof(cl_int),nullptr, &err);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for res_mem\n";
        return err;
    }

    cl_mem p0_mem;
    if(isSigned0)
    {
        p0_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(sc_p0), &sc_p0, &err);
    }
    else
    {
        p0_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(uc_p0), &uc_p0, &err);
    }
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for p0_mem\n";
        return err;
    }

    cl_mem p1_mem;
    if(isSigned1)
    {
        p1_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(sc_p1), &sc_p1, &err);
    }
    else
    {
        p1_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(uc_p1), &uc_p1, &err);
    }
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for p1_mem\n";
        return err;
    }

    cl_mem acc_mem;
    if(isSigned0 || isSigned1)
    {
        acc_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(sacc), &sacc, &err);
    }
    else
    {
        acc_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(uacc), &uacc, &err);
    }
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for acc_mem\n";
        return err;
    }

    /*
     * Set kernel arguments
     */
    err = clSetKernelArg(kernel, 0, sizeof(res_mem), &res_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 0.\n";
        return err;
    }

    err = clSetKernelArg(kernel, 1, sizeof (p0_mem), &p0_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 1.\n";
        return err;
    }

    err = clSetKernelArg(kernel, 2, sizeof(p1_mem), &p1_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 2.\n";
        return err;
    }

    err = clSetKernelArg(kernel, 3, sizeof(acc_mem), &acc_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 3.\n";
        return err;
    }

    /*
     * Launch kernel
     */
    size_t global_work_size = 1;
    err = clEnqueueNDRangeKernel(
            command_queue,
            kernel,
            1,                      // work dimension of input buffer
            nullptr,
            &global_work_size,
            nullptr,
            0,
            nullptr,
            nullptr
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clEnqueueNDRangeKernel.\n";
        return err;
    }

    clFinish(command_queue);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while finishing the command queue.\n";
        return err;
    }

    /*
     * Map buffer for reading and compare against reference values
     */
    cl_int *hostptr = static_cast<cl_int*>(clEnqueueMapBuffer(
            command_queue,
            res_mem,
            CL_BLOCKING,            //Extra precaution, can be CL_NON_BLOCKING. Necessary if clFinish were removed.
            CL_MAP_READ,
            0,
            sizeof(cl_int),
            0,
            nullptr,
            nullptr,
            &err
    ));
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while mapping output buffer.\n";
        return err;
    }

    if(isSigned0 || isSigned1)
    {
        cl_int ref=0;
        if(isSigned0 && isSigned1)
        {
            ref=dot_acc_sat(sc_p0, sc_p1, sacc);
        }
        else if(!isSigned0 && isSigned1)
        {
            ref=dot_acc_sat(uc_p0, sc_p1, sacc);
        }
        else if(isSigned0 && !isSigned1)
        {
            ref=dot_acc_sat(sc_p0, uc_p1, sacc);
        }
        if (*hostptr != ref) {
            std::cerr << "Mismatch. (unpacked) Expected: " << ref << " Actual: " << *hostptr << std::endl;
            return EXIT_FAILURE;
        } else {
            std::cout << "Reference (unpacked): " << ref << " Actual: " << *hostptr << std::endl;
        }
    }
    else
    {
        cl_uint ref = dot_acc_sat(uc_p0, uc_p1, uacc);
        if (*hostptr != ref) {
            std::cerr << "Mismatch. (unpacked) Expected: " << ref << " Actual: " << *hostptr << std::endl;
            return EXIT_FAILURE;
        } else {
            std::cout << "Reference (unpacked): " << ref << " Actual: " << *hostptr << std::endl;
        }
    }

    /*
     * Cleanup
     */
    err = clEnqueueUnmapMemObject(command_queue, res_mem, hostptr, 0, nullptr, nullptr);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while unmapping output buffer.\n";
        return err;
    }

    err = clReleaseMemObject(res_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing res_mem.\n";
        return err;
    }
    err = clReleaseMemObject(p0_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing p0_mem.\n";
        return err;
    }
    err = clReleaseMemObject(p1_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing p1_mem.\n";
        return err;
    }
    err = clReleaseMemObject(acc_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing acc_mem.\n";
        return err;
    }

    return EXIT_SUCCESS;
}
