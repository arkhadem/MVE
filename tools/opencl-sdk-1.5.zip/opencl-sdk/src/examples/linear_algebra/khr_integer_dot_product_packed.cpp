//--------------------------------------------------------------------------------------
// File: khr_integer_dot_product_packed.cpp
// Desc: This example demonstrates the usage of cl_khr_integer_dot_product
//
// Author:      QUALCOMM
//
//          Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <CL/cl.h>
#include "util/cl_wrapper.h"

static const char *PROGRAM_SOURCE = R"(
    __kernel void dot_acc_sat_packed_uu_uint(
                  __global uint *res,
                  __global uint *p0,
                  __global uint *p1,
                  __global uint *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat_4x8packed_uu_uint(p0[i], p1[i], acc[i]);
    }
    __kernel void dot_acc_sat_packed_ss_int(
                  __global int *res,
                  __global uint *p0,
                  __global uint *p1,
                  __global int *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat_4x8packed_ss_int(p0[i], p1[i], acc[i]);
    }
    __kernel void dot_acc_sat_packed_us_int(
                  __global int *res,
                  __global uint *p0,
                  __global uint *p1,
                  __global int *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat_4x8packed_us_int(p0[i], p1[i], acc[i]);
    }
    __kernel void dot_acc_sat_packed_su_int(
                  __global int *res,
                  __global uint *p0,
                  __global uint *p1,
                  __global int *acc)
    {
        int i = get_global_id(0);
        res[i] = dot_acc_sat_4x8packed_su_int(p0[i], p1[i], acc[i]);
    }
)";

int saturated_add(int a, int b)
{
    if (a > 0 && b > INT32_MAX - a)
    {
        return INT32_MAX;
    }
    else if (a < 0 && b < INT32_MIN - a)
    {
        return INT32_MIN;
    }
    return a + b;
}

uint saturated_add(uint a, uint b)
{
    if(b > UINT32_MAX - a)
    {
        return UINT32_MAX;
    }
    return a + b;
}

template <typename DestT>
DestT dot_acc_sat_4x8packed_TT_Tint(cl_uint p0, bool isSigned0, cl_uint p1, bool isSigned1, DestT acc)
{
    cl_char  p0as, p0bs, p0cs, p0ds, p1as, p1bs, p1cs, p1ds;
    cl_uchar p0au, p0bu, p0cu, p0du, p1au, p1bu, p1cu, p1du;
    DestT dot_product;

    if(isSigned0)
    {
        p0as = static_cast<cl_char>((p0 >> 24) & 0xFF);
        p0bs = static_cast<cl_char>((p0 >> 16) & 0xFF);
        p0cs = static_cast<cl_char>((p0 >> 8) & 0xFF);
        p0ds = static_cast<cl_char>(p0 & 0xFF);
    }
    else
    {
        p0au = ((p0 >> 24) & 0xFF);
        p0bu = ((p0 >> 16) & 0xFF);
        p0cu = ((p0 >> 8) & 0xFF);
        p0du = (p0 & 0xFF);
    }

    if(isSigned1)
    {
        p1as = static_cast<cl_char>((p1 >> 24) & 0xFF);
        p1bs = static_cast<cl_char>((p1 >> 16) & 0xFF);
        p1cs = static_cast<cl_char>((p1 >> 8) & 0xFF);
        p1ds = static_cast<cl_char>(p1 & 0xFF);
    }
    else
    {
        p1au = ((p1 >> 24) & 0xFF);
        p1bu = ((p1 >> 16) & 0xFF);
        p1cu = ((p1 >> 8) & 0xFF);
        p1du = (p1 & 0xFF);
    }

    if(isSigned0 && isSigned1)
    {
        dot_product = p0as * p1as + p0bs * p1bs + p0cs * p1cs + p0ds * p1ds;
    }
    else if(!isSigned0 && isSigned1)
    {
        dot_product = p0au * p1as + p0bu * p1bs + p0cu * p1cs + p0du * p1ds;
    }
    else if(isSigned0 && !isSigned1)
    {
        dot_product = p0as * p1au + p0bs * p1bu + p0cs * p1cu + p0ds * p1du;
    }
    else
    {
        dot_product = p0au * p1au + p0bu * p1bu + p0cu * p1cu + p0du * p1du;
    }

    return saturated_add(dot_product, acc);
}

int main(int argc, char** argv)
{
    if (argc != 3)
    {
        std::cerr << "Usage: " << argv[0] << " <sign1> <sign2>\n"
                     "\t<sign1> = signed | unsigned\n"
                     "\t<sign2> = signed | unsigned\n";
        return EXIT_FAILURE;
    }

    if((strcmp(argv[1],"signed") != 0 && strcmp(argv[1],"unsigned") != 0)
        || (strcmp(argv[2],"signed") != 0 && strcmp(argv[2],"unsigned") != 0))
    {
        std::cerr << "Usage: " << argv[0] << " <sign1> <sign2>\n"
                     "\t<sign1> = signed | unsigned\n"
                     "\t<sign2> = signed | unsigned\n";
        return EXIT_FAILURE;
    }

    bool isSigned0 = strcmp(argv[1],"signed") == 0;
    bool isSigned1 = strcmp(argv[2],"signed") == 0;

    cl_wrapper         wrapper;
    cl_program         program       = wrapper.make_program(&PROGRAM_SOURCE, 1, "-cl-std=CL3.0");
    cl_kernel          kernel;
    cl_context         context       = wrapper.get_context();
    cl_command_queue   command_queue = wrapper.get_command_queue();
    cl_int             err           = CL_SUCCESS;

    if(isSigned0 && isSigned1)
    {
        kernel = wrapper.make_kernel("dot_acc_sat_packed_ss_int", program);
    }
    else if(isSigned0 && !isSigned1)
    {
        kernel = wrapper.make_kernel("dot_acc_sat_packed_su_int", program);
    }
    else if(!isSigned0 && isSigned1)
    {
        kernel = wrapper.make_kernel("dot_acc_sat_packed_us_int", program);
    }
    else
    {
        kernel = wrapper.make_kernel("dot_acc_sat_packed_uu_uint", program);
    }

    // Setup example
    cl_uint uacc;
    cl_int sacc;
    cl_uchar p0a = (isSigned0) ? -11 : 11;
    cl_uchar p0b = 22;
    cl_uchar p0c = (isSigned0) ? -33 : 33;
    cl_uchar p0d = 44;
    cl_uchar p1a = 55;
    cl_uchar p1b = (isSigned1) ? -66 : 66;
    cl_uchar p1c = 77;
    cl_uchar p1d = (isSigned1) ? -88 : 88;
    cl_uint  p0  = (p0a << 24) | (p0b << 16) | (p0c << 8) | p0d;
    cl_uint  p1  = (p1a << 24) | (p1b << 16) | (p1c << 8) | p1d;
    sacc= (isSigned0 || isSigned1)? -9 : 9;
    uacc= (cl_uint) sacc;

    std::cout << "p0: " << p0 << " p1: " << p1 << " acc: " << sacc << std::endl;

    /*
     * Confirm the required OpenCL extensions are supported.
     */
    if (!wrapper.check_extension_support("cl_khr_integer_dot_product"))
    {
        std::cerr << "cl_khr_integer_dot_product extension is not supported.\n";
        return EXIT_FAILURE;
    }

    /*
     * Allocate device memory
     */
    cl_mem res_mem = clCreateBuffer(context,CL_MEM_HOST_READ_ONLY | CL_MEM_WRITE_ONLY, sizeof(cl_int),nullptr, &err);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for res_mem\n";
        return err;
    }

    cl_mem p0_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof (cl_uint), &p0, &err);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for p0_mem\n";
        return err;
    }

    cl_mem p1_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(cl_uint), &p1, &err);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for p1_mem\n";
        return err;
    }

    cl_mem acc_mem;
    if(isSigned0 || isSigned1)
    {
        acc_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(cl_int), &sacc, &err);
    }
    else
    {
        acc_mem = clCreateBuffer(context, CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_NO_ACCESS | CL_MEM_READ_ONLY, sizeof(cl_int), &uacc, &err);
    }
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clCreateBuffer for acc_mem\n";
        return err;
    }

    /*
     * Set kernel arguments
     */
    err = clSetKernelArg(kernel, 0, sizeof(res_mem), &res_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 0.\n";
        return err;
    }

    err = clSetKernelArg(kernel, 1, sizeof (p0_mem), &p0_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 1.\n";
        return err;
    }

    err = clSetKernelArg(kernel, 2, sizeof(p1_mem), &p1_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 2.\n";
        return err;
    }

    err = clSetKernelArg(kernel, 3, sizeof(acc_mem), &acc_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clSetKernelArg for argument 3.\n";
        return err;
    }

    /*
     * Launch kernel
     */
    static const size_t global_work_size = 1;
    err = clEnqueueNDRangeKernel(
            command_queue,
            kernel,
            1, // work dimension of input buffer
            nullptr,
            &global_work_size,
            nullptr,
            0,
            nullptr,
            nullptr
    );
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " with clEnqueueNDRangeKernel.\n";
        return err;
    }

    clFinish(command_queue);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while finishing the command queue.\n";
        return err;
    }

    /*
     * Map buffer for reading and compare against reference values
     */
    cl_int *hostptr = static_cast<cl_int*>(clEnqueueMapBuffer(
            command_queue,
            res_mem,
            CL_BLOCKING,    //Extra precaution, can be CL_NON_BLOCKING. Necessary if clFinish were removed.
            CL_MAP_READ,
            0,
            sizeof(cl_int),
            0,
            nullptr,
            nullptr,
            &err
    ));
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while mapping output buffer.\n";
        return err;
    }

    if(isSigned0 || isSigned1) {
        cl_int ref = dot_acc_sat_4x8packed_TT_Tint(p0, isSigned0, p1, isSigned1, sacc);
        if (*hostptr != ref) {
            std::cerr << "Mismatch. (Packed) Expected: " << ref << " Actual: " << *hostptr << std::endl;
            return EXIT_FAILURE;
        } else {
            std::cout << "Reference (Packed): " << ref << " Actual: " << *hostptr << std::endl;
        }
    }
    else
    {
        cl_uint ref = dot_acc_sat_4x8packed_TT_Tint(p0, isSigned0, p1, isSigned1, uacc);
        if (*hostptr != ref) {
            std::cerr << "Mismatch. (Packed) Expected: " << ref << " Actual: " << *hostptr << std::endl;
            return EXIT_FAILURE;
        } else {
            std::cout << "Reference (Packed): " << ref << " Actual: " << *hostptr << std::endl;
        }
    }

    /*
     * Cleanup
     */
    err = clEnqueueUnmapMemObject(command_queue, res_mem, hostptr, 0, nullptr, nullptr);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while unmapping output buffer.\n";
        return err;
    }

    err = clReleaseMemObject(res_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing res_mem.\n";
        return err;
    }
    err = clReleaseMemObject(p0_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing p0_mem.\n";
        return err;
    }
    err = clReleaseMemObject(p1_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing p1_mem.\n";
        return err;
    }
    err = clReleaseMemObject(acc_mem);
    if (err != CL_SUCCESS)
    {
        std::cerr << "Error " << err << " while releasing acc_mem.\n";
        return err;
    }

    return EXIT_SUCCESS;
}
