//--------------------------------------------------------------------------------------
// File: ext_image_from_buffer.cpp
// Desc: This example demonstrates the usage of cl_ext_image_from_buffer for RGBA 2D images
//       and RGBA 2D image arrays.
//
// Author:      QUALCOMM
//
//          Copyright (c) 2022 QUALCOMM Technologies, Inc.
//                         All Rights Reserved.
//                      QUALCOMM Proprietary/GTDR
//--------------------------------------------------------------------------------------

#include <iostream>
#include <cstring>
#include <cmath>
#include <CL/cl.h>
#include "util/cl_wrapper.h"
#include <CL/cl_ext_qcom.h>

#define IMAGE_WIDTH 8

static const char *PROGRAM_SOURCE = R"(
    __kernel void copy_image(__read_only  image2d_t src,
                             __write_only image2d_t dst)
    {
        const sampler_t nearest_sampler = CLK_NORMALIZED_COORDS_FALSE |
                                          CLK_ADDRESS_CLAMP_TO_EDGE   |
                                          CLK_FILTER_NEAREST;

        const int    wid_x = get_global_id(0);
        const int    wid_y = get_global_id(1);
        const int2   coord = (int2)(wid_x, wid_y);
        const float4  pixel = read_imagef(src, nearest_sampler, coord);
        write_imagef(dst, coord, pixel);
    }

    __kernel void copy_image_array(__read_only  image2d_array_t src,
                                   __write_only image2d_array_t dst)
    {
        const sampler_t nearest_sampler = CLK_NORMALIZED_COORDS_FALSE |
                                          CLK_ADDRESS_CLAMP_TO_EDGE   |
                                          CLK_FILTER_NEAREST;

        const int    wid_x = get_global_id(0);
        const int    wid_y = get_global_id(1);
        const int    wid_z = get_global_id(2);
        const int4   coord = (int4)(wid_x, wid_y, wid_z, 0);
        const float4  pixel = read_imagef(src, nearest_sampler, coord);
        write_imagef(dst, coord, pixel);
    }
)";

inline void cl_err_check(cl_int &err, const char * file, const unsigned int line, const char* fmt...)
{
    va_list args;
    const size_t mesg_size = 100;   //Assumes message size
    char mesg[mesg_size];

    if (err != CL_SUCCESS)
    {
        va_start(args, fmt);
        vsnprintf(mesg, mesg_size, fmt, args);
        va_end(args);

        fprintf(stderr, "%s:%d  %s" , file, line, mesg);

        exit(static_cast<int>(err));
    }
}

inline void compare_results(size_t i, cl_uint src_ref, cl_uint dst_result, size_t &mismatched)
{
    if (src_ref!=dst_result)
    {
        std::cerr << "Failed at input " << i
                  << " result: " << dst_result
                  << " reference: " << src_ref
                  << " error: " << ((dst_result>src_ref) ? dst_result - src_ref: src_ref - dst_result)<< "\n";
        ++mismatched;
    }
}

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        std::cerr << "Usage: " << argv[0] << " <image_format>\n"
                                             "\t<image_format> = rgba8888 | rgba8888_array\n";
        return EXIT_FAILURE;
    }

    if(strcmp(argv[1],"rgba8888") != 0
       && strcmp(argv[1],"rgba8888_array") != 0)
    {
        std::cerr << "Usage: " << argv[0] << " <image_format>\n"
                                             "\t<image_format> = rgba8888 | rgba8888_array\n";
        return EXIT_FAILURE;
    }

    bool isRGBA_2Darray = strcmp(argv[1], "rgba8888_array") == 0;

    cl_wrapper         wrapper;
    cl_program         program              = wrapper.make_program(&PROGRAM_SOURCE, 1, "-cl-std=CL3.0");
    cl_kernel          copyImageKernel      = wrapper.make_kernel("copy_image", program);
    cl_kernel          copyImageArrayKernel = wrapper.make_kernel("copy_image_array", program);
    cl_context         context              = wrapper.get_context();
    cl_command_queue   command_queue        = wrapper.get_command_queue();
    cl_int             err                  = CL_SUCCESS;

    /*
     * Confirm the required OpenCL extensions are supported.
    */
    if (!wrapper.check_extension_support("cl_ext_image_requirements_info")) //Pre-requisite of cl_ext_image_from_buffer.
    {
        std::cerr << "cl_ext_image_requirements_info extension is not supported.\n";
        return EXIT_FAILURE;
    }
    if (!wrapper.check_extension_support("cl_ext_image_from_buffer"))
    {
        std::cerr << "cl_ext_image_from_buffer extension is not supported.\n";
        return EXIT_FAILURE;
    }

    //Step 1: Create Image descriptors
    cl_image_format imageFormat {CL_RGBA, CL_UNORM_INT8};
    cl_mem_object_type memObjectType = (isRGBA_2Darray) ? CL_MEM_OBJECT_IMAGE2D_ARRAY : CL_MEM_OBJECT_IMAGE2D ;
    cl_image_desc srcImageDesc = {memObjectType,
                                IMAGE_WIDTH,
                                IMAGE_WIDTH};
    cl_image_desc dstImageDesc = {memObjectType,
                                IMAGE_WIDTH,
                                IMAGE_WIDTH};

    if(isRGBA_2Darray)
    {
        srcImageDesc.image_array_size = IMAGE_WIDTH;
        dstImageDesc.image_array_size = IMAGE_WIDTH;
    }

    size_t srcOrigin[]         = {0,0,0};
    size_t srcRegion[]         = {srcImageDesc.image_width, srcImageDesc.image_height, 1};
    size_t dstOrigin[]         = {0,0,0};
    size_t dstRegion[]         = {dstImageDesc.image_width, dstImageDesc.image_height, 1};

    if(isRGBA_2Darray)
    {
        srcRegion[2] = srcImageDesc.image_array_size;
        dstRegion[2] = dstImageDesc.image_array_size;
    }

    //Step 2: Allocate buffer for src
    size_t srcImageSize = 0;
    err = clGetImageRequirementsInfoEXT(
            context, nullptr, 0, &imageFormat, &srcImageDesc,
            CL_IMAGE_REQUIREMENTS_SIZE_EXT,
            sizeof(srcImageSize), &srcImageSize, nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error getting size", err);

    cl_mem buffer_for_image = clCreateBuffer(context,
                                        CL_MEM_READ_WRITE,
                                        srcImageSize,
                                        nullptr, &err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while using clCreateBuffer\n", err);
    srcImageDesc.buffer = buffer_for_image;

    //Step 3: Create src and dst images
    cl_mem src_rgba_image = clCreateImage(
            context,
            CL_MEM_HOST_WRITE_ONLY | CL_MEM_READ_ONLY,
            &imageFormat,
            &srcImageDesc,
            nullptr,&err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while using clCreateImage\n", err);

    cl_mem dst_rgba_image = clCreateImage(
            context,
            CL_MEM_HOST_READ_ONLY | CL_MEM_WRITE_ONLY,
            &imageFormat,
            &dstImageDesc,
            nullptr,&err);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while using clCreateImage\n", err);


    //Step 4: Initialize source buffer to 0xff
    size_t srcElementSize = 0;
    err = clGetImageInfo(src_rgba_image, CL_IMAGE_ELEMENT_SIZE, sizeof(srcElementSize), &srcElementSize, nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while using clGetImageInfo\n", err);

    size_t srcRowPitch = 0;
    size_t srcSlicePitch = 0;
    cl_uint *srcImgPtr = static_cast<cl_uint *>(clEnqueueMapImage(
            command_queue,
            src_rgba_image,
            CL_BLOCKING,
            CL_MAP_WRITE,
            srcOrigin,
            srcRegion,
            &srcRowPitch,
            &srcSlicePitch,
            0,
            nullptr,
            nullptr,
            &err
    ));
    cl_err_check(err, __FILE__, __LINE__, "Error %d while using clEnqueueMapImage\n", err);

    unsigned char bytePattern = 0xff;
    cl_uint pattern = bytePattern << 24
                    | bytePattern << 16
                    | bytePattern << 8
                    | bytePattern ;
    if(isRGBA_2Darray)
    {
        for(size_t s = 0; s < srcImageDesc.image_array_size; ++s){
            for (size_t i = 0; i < srcImageDesc.image_height; ++i){
                memset(srcImgPtr + s * (srcSlicePitch/srcElementSize) + i * (srcRowPitch/srcElementSize),
                       bytePattern, srcImageDesc.image_width * srcElementSize);
            }
        }
    }
    else {
        for (size_t i = 0; i < srcImageDesc.image_height; ++i) {
            memset(srcImgPtr + i * (srcRowPitch / srcElementSize), bytePattern, srcImageDesc.image_width * srcElementSize);
        }
    }

    err = clEnqueueUnmapMemObject(command_queue, src_rgba_image, srcImgPtr, 0, nullptr, nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while running clEnqueueUnmapMemObject.\n", err);

    //Step 5: Bind kernel arguments
    cl_kernel kernel = (isRGBA_2Darray)? copyImageArrayKernel : copyImageKernel;
    err= clSetKernelArg(kernel, 0, sizeof(src_rgba_image), &src_rgba_image);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 0.\n", err);

    err = clSetKernelArg(kernel, 1, sizeof(dst_rgba_image), &dst_rgba_image);
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clSetKernelArg for argument 1.\n", err);

    //Step 6: Launch copy image kernel
    size_t global_work_size[3] = {srcImageDesc.image_width, srcImageDesc.image_height, 1};
    size_t work_dim = (isRGBA_2Darray) ? 3 : 2;
    global_work_size[2] = (isRGBA_2Darray) ? srcImageDesc.image_array_size : 0;
    err = clEnqueueNDRangeKernel(
            command_queue,
            kernel,
            work_dim,
            nullptr,
            global_work_size,
            nullptr,
            0,
            nullptr,
            nullptr
    );
    cl_err_check(err, __FILE__, __LINE__, "Error %d with clEnqueueNDRangeKernel.\n", err);

    // clFinish could be used here as an alternative to CL_BLOCKING (in the clEnqueueMapImage below) to
    // prevent mapping and reading while the compute device finishes.

    //Step 7: Map result from kernel to host buffer
    size_t dstElementSize = 0;
    err = clGetImageInfo(src_rgba_image, CL_IMAGE_ELEMENT_SIZE, sizeof(dstElementSize),
                         &dstElementSize, nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while using clGetImageInfo\n", err);

    size_t dstRowPitch = 0;
    size_t dstSlicePitch = 0;
    cl_uint *dstImgPtr = static_cast<cl_uint *>(clEnqueueMapImage(
            command_queue,
            dst_rgba_image,
            CL_BLOCKING,
            CL_MAP_READ,
            dstOrigin,
            dstRegion,
            &dstRowPitch,
            &dstSlicePitch,
            0,
            nullptr,
            nullptr,
            &err
    ));
    cl_err_check(err, __FILE__, __LINE__, "Error %d while using clEnqueueMapImage\n", err);


    //Step 8: Compare with reference values
    size_t mismatched = 0;
    if(!isRGBA_2Darray){
        for (size_t i = 0; i < dstImageDesc.image_height; ++i){
            for (size_t j = 0; j < dstImageDesc.image_width; ++j) {
                compare_results(i * dstImageDesc.image_width + j,
                                pattern,
                                dstImgPtr[i * dstRowPitch/dstElementSize + j],
                                mismatched);
            }
        }
    }
    else
    {
        for(size_t i = 0; i < dstImageDesc.image_array_size; ++i) {
            for (size_t j = 0; j < dstImageDesc.image_height; ++j) {
                for (size_t k = 0; k < dstImageDesc.image_width; ++k) {
                    compare_results(i * dstImageDesc.image_height * dstImageDesc.image_width + j * dstImageDesc.image_width + k,
                                    pattern,
                                    dstImgPtr[i * (dstSlicePitch / dstElementSize) +
                                              j * (dstRowPitch / dstElementSize) + k],
                                    mismatched);
                }
            }
        }
    }

    if(mismatched){
        std::cout<< mismatched << " out of " << global_work_size[0] * global_work_size[1] * global_work_size[2]
                 << " didn't match.\n";
    }
    else{
        std::cout<< "All reference and accelerated results match.\n";
    }

    err = clEnqueueUnmapMemObject(command_queue, dst_rgba_image, dstImgPtr,
                                  0, nullptr, nullptr);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while running clEnqueueUnmapMemObject.\n", err);


    //Step 9: Release OpenCL objects
    err = clReleaseMemObject(dst_rgba_image);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing dst_rgba_image.\n", err);
    err = clReleaseMemObject(src_rgba_image);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing src_rgba_image.\n", err);
    err = clReleaseMemObject(buffer_for_image);
    cl_err_check(err, __FILE__, __LINE__, "Error %d while releasing buffer_for_image.\n", err);

    if(mismatched)
    {
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}