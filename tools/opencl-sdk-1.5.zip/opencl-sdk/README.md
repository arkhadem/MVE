# Qualcomm OpenCL SDK

This software development kit includes extension documents, Open Compute Language header files including for Qualcomm
extensions, and code examples that demonstrate image processing, linear algebra, machine learning, and usage of Qualcomm
extensions implemented with OpenCL.

These examples have been tested on SM 8550 hardware with Android 13.

The cl_qcom_ml_ops SDK is distributed separately.

## Building for Android 13

These steps work on any operating system, such as Linux and Windows, that supports the Android native development kit.

1. Obtain the prerequisites.
   * Download the [Android Open Source Project](https://source.android.com).
   * Build the following Android dependencies:
     * `kernel`
     * `libdmabufheap libvmmem`, or if using Android 11 or earlier, `libion`
     * `libhardware libui libutils` (optional)
   * Locate `libOpenCL.so` or `libOpenCL_system.so` (depending on whether Android's vendor or system partition is
     desired) from the Android Open Source Project tree or from Qualcomm hardware flashed with Android.
   * Optionally locate `libEGL.so` and `libGLESv2.so` from the same.
   * Optionally download `/path/to/aosp/vendor/qcom/opensource/commonsys-intf/display/gralloc` from
     https://www.codeaurora.org.
   * Optionally download the GLES2 headers at https://www.khronos.org/registry/OpenGL/api/GLES2 into `inc/GLES2` and the
     EGL headers at https://registry.khronos.org/OpenGL/api/GLES into `inc/EGL` within the SDK.
   * Set up the Android NDK. The easiest way is to use [Android Studio](https://developer.android.com/studio).
     * On the welcome screen, click Configure > SDK Manager.
     * Under SDK Tools, tick "Show Package Details" and install NDK (Side by side) > 25.1.8937393. Newer would likely
       work too.

2. Build the OpenCL SDK with CMake.
   * Open this directory in [CMake GUI](https://cmake.org) as a source directory.
   * Choose an out-of-source CMake build directory.
   * Add the following CMake variables before asking CMake to configure:
      * `CMAKE_TOOLCHAIN_FILE=/path/to/android-sdk/ndk/<version>/build/cmake/android.toolchain.cmake`
      * `ANDROID_PLATFORM=30`
      * `ANDROID_ABI=arm64-v8a`
   * Optionally click Configure to make setting the following variables easier.
   * Select a generator capable of building for Linux, such as [Ninja](https://ninja-build.org).
   * Set the following CMake variables:
      * `CLSDK_OPENCL_LIB=/path/to/libOpenCL_system.so` (Or use `libOpenCL.so` for Android's vendor partition.)
      * `ANDROID_PATH=/path/to/aosp`
   * Set the following CMake variables to build libdmabuf needed by most samples:
     * `VENDOR_ION_HEADERS=/path/to/linux/msm_ion.h`
     * `CLSDK_VMMEM_LIB=/path/to/libvmmem.so`
     * `CLSDK_DMABUF_LIB=/path/to/libdmabufheap.so`
   * Optionally set some or all of the following CMake variables to build extra examples. CMake will warn about examples
     that could be built if their optional dependencies were satisfied while configuring.
     * `CLSDK_NATIVEWINDOW_LIB=/path/to/libnativewindow.so`
     * `CLSDK_UI_LIB=/path/to/libui.so`
     * `CLSDK_UTILS_LIB=/path/to/libutils.so`
     * `CLSDK_EGL_LIB=/path/to/libEGL.so`
     * `CLSDK_GLESv2_LIB=/path/to/libGLESv2.so`
   * Optionally set the following CMake variables to build the ION specific examples:
     * `CLSDK_KERNEL_HEADERS=/path/to/aosp/out/target/product/name/obj/KERNEL_OBJ/usr/include`
       (It must contain `linux/msm_ion.h`.)
     * `CLSDK_ION_LIB=/path/to/libion.so`
   * Click Generate.
   * Click Finish.
   * Build on the command line: `cmake --build /path/to/build/directory`

## Usage

Building will produce a set of binaries. Run each one without arguments to see a help message that describes any
required input image formats and what it does. Several sample images are provided in the `example_images` directory,
which contain arbitrary data that isn't visually interesting.

## Descriptions

### src/examples/accelerated_image_ops/

Demonstrates various built-in function usage that are part of the `cl_qcom_accelerated_image_ops` extension.

#### accelerated_convolution.cpp

Demonstrates a gaussian blur filter using the `qcom_convolve_imagef` built-in function. Additionally, demonstrates that
images and buffers can use the same underlying dmabuf memory, by writing to an OpenCL buffer and reading results from an
image.

#### hof_filter.cpp

Demonstrates the use of higher order separable and non-separable filters with the qcom_convolve_imagef built-in
function.

#### qcom_block_match_sad.cpp, qcom_block_match_ssd.cpp, qcom_box_filter_image.cpp, qcom_convolve_image.cpp

Demonstrates basic usage for the named built-in extension functions. Look here for minimal examples of how to use the
extensions.

#### qcom_filter_bicubic.cpp

Demonstrates up-scaling an image using the Qualcomm `cl_qcom_filter_bicubic` extension.

### src/examples/basic/

#### ahardwarebuffer_buffer.cpp, ahardwarebuffer_image.cpp

Demonstrates the use of the `cl_qcom_android_ahardwarebuffer_host_ptr` extension with OpenCL buffers and images.

#### cl_egl_sync.cpp

Demonstrates the use of the `cl_khr_gl_sharing` extension to sync between OpenCL, GL, and EGL.

#### hello_world.cpp

Demonstrates OpenCL 2.0 usage by simply copying one buffer to another.

#### hello_world_3_0.cpp

Demonstrates OpenCL 3.0 usage by simply copying one buffer to another.

#### qcom_extended_query_image_info.cpp

Demonstrates the use of the `cl_qcom_extended_query_image_info` extension.

#### qcom_perf_hint.cpp

Demonstrates the use of the `cl_qcom_perf_hint` extension.

#### qcom_reqd_sub_group_size.cpp

Demonstrates the use of the `cl_qcom_reqd_sub_group_size` extension. It can be used to manually tune the sub-group size
for performance.

#### tuning_wgs.cpp

Demonstrates a method to find an optimal local work-group size (in terms of the least execution time) for a kernel.

### src/examples/dmabuf_buffer_and_image/

Demonstrates the use of dmabuf-backed buffers and images. Both examples simply copy a buffer or image. This is a
standalone example and does not require the wrapper.

### src/examples/image_conversions/

Demonstrates conversions to and from various image formats. In many cases, this involves an additional initial pass to
convert a linear image to the desired source format for conversion or to convert the destination image of the conversion
to a linear image for writing to file.

#### bayer_mipi10_to_rgba.cpp and unpacked_bayer_to_rgba.cpp

Demonstrates a scheme for demosaicing. The former uses the packed `MIPI10` format and the latter uses an unpacked 10-bit
format (held in a 16-bit int with 6 bits unused). Both use Bayer-ordered images to exploit the graphical processing
unit's interpolation capabilities without mixing different color channels. The destination format has 8-bits per
channel, so some precision is lost.

#### compressed_image_nv12.cpp and compressed_image_rgba.cpp

Demonstrates use of compressed images using Qualcomm OpenCL extensions. The input image is compressed and then
decompressed, with the result written to the specified output file for comparison. (The compression is not lossy, so
they are identical.)

Compressed image formats may be saved to disk, however the format is GPU specific.

The two examples show compression for NV12 and RGBA images.

#### mipi10_to_unpacked.cpp and unpacked_to_mipi10.cpp

Demonstrates using the MIPI10 data format with a single-channel `CL_R` order. The former converts a packed MIPI10 image
into an unpacked 10-bit image. The latter shows the unpacked-to-packed conversion.

#### nv21_to_compressed_nv12.cpp

Unlike the other image conversion examples that use dmabuf, this example uses Android Native Buffer.

#### nv12_to_nv12_compressed.cpp, nv12_to_nv12_compressed_to_rgba.cpp, tp10_to_compressed_tp10_to_p010.cpp, nv12_to_rgb565.cpp

Demonstrates image conversions, however instead of using dmabuf they use Android hardware buffer.

### src/examples/ion_buffer_and_image/

This is the ION counterpart for the dmabuf_buffer_and_image example. It demonstrates the IO-coherent and uncached host
cache policies for ION buffers and images. Other than the parameters used to create the ION buffers, there is no
difference in the host or kernel code for IO-coherent or uncached policies. This is a standalone example and does not
require the wrapper.

### src/examples/linear_algebra/

Demonstrates the basic linear algebra operations:
* Matrix addition
* Matrix multiplication
* Matrix transposition

The transposition and multiplication examples come in two flavors, one using OpenCL buffers and another that packs the
matrices into 2-dimensional images. It is not a foregone conclusion that using an image or a buffer will enjoy better
performance  in any given use case, so generally one must try and see what works best.

The image versions of both examples pad irregularly sized matrices, both because images have per-row alignment
requirements and because this permits an efficient tiled algorithm to be applied uniformly. This approach can use
substantially more memory than the buffer-based version.

In contrast, the buffer versions do not pad the input matrices. They use an efficient tiled algorithm where possible,
and a less efficient algorithm to calculate the remaining portion of the output not covered by the tiled algorithm.

The multiplication examples additionally have a "half" variant, that demonstrates using the 16-bit half-float data type.
The input, output and arithmetic all use half-floats. This can be a significant performance advantage, although it
introduces more error. One may mix use of floats and half-floats to achieve the desired performance/accuracy trade off.

#### convolution.cpp

Demonstrates efficient convolution without the use of built-in extension functions.

#### fft_matrix.cpp

Demonstrates the 2D fast Fourier transform of a matrix using the in-place Cooley-Tukey algorithm. First in the "row
pass" each work group calculates the 1D FFT of a row. The intermediate result is transposed and written to global
memory. This procedure is then repeated in a "column pass" that acts on the rows of the result of the first pass. The
result is transposed, producing the final result. Calculating the 1D FFTs back-to-back in this way is equal to the 2D
FFT.

Demonstrates a real-valued matrix as input and produces two matrices as the output holding the real and imaginary parts
of the FFT.

#### qcom_bitreverse.cpp

Demonstrates the use of the `cl_qcom_bitreverse` extension by reversing the bits of an array of prime numbers.

#### qcom_dot_product8.cpp

Demonstrates the use of the `cl_qcom_dot_product8` extension.

#### svm_matrix_multiplicaton.cpp

Processes data on the host and device without using expensive `clFinish` synchronization. Instead, locks are used on
shared virtual memory allocations.

### src/examples/protected_memory/

Demonstrates creation and initialization of GPU memory that's protected from being read or written by the central
processing unit. One of several backing stores is used by each example.

#### protected_android_hardware_buffer.cpp

Demonstrates use of the `cl_qcom_protected_context` and `cl_qcom_android_ahardwarebuffer_host_ptr` extensions.

#### protected_android_native_buffer.cpp

Demonstrates use of the `cl_qcom_protected_context` and `cl_qcom_android_native_buffer_host_ptr` extensions.

#### protected_dmabuf.cpp

Demonstrates use of the `cl_qcom_protected_context` and `cl_qcom_dmabuf_host_ptr` extensions.

#### protected_ion.cpp

Demonstrates use of the `cl_qcom_protected_context` and `cl_qcom_ion_host_ptr` extensions.

### src/examples/recordable_queues/

Demonstrates recording multiple kernel enqueues. It multiplies two simple matrices, and then increments every element of
the result many times.  The increment kernel increments by one for every run. Additionally, it shows how a single kernel
parameter can be updated without re-recording the entire enqueue sequence.

### src/examples/vector_image_ops/

Demonstrates a variety of kernels using vector read and write operations for the given image formats.

## Image Data Format

Input and output images have the following format, where multibyte data types are written with the least significant
byte first:
* 4 bytes: Plane width in pixels as an unsigned integer.
* 4 bytes: Plane height as an unsigned integer.
* 4 bytes: OpenCL channel data type.
* 4 bytes: OpenCL channel order.
* N bytes: Pixel data, where N is dependent on the preceding four values.

## Matrix Data Format

Matrices used by the examples in the `linear_algebra` directory have the following plain text format:
* Two integers separated by whitespace indicating the number of columns and rows of the matrix.
* A sequence of whitespace-separated floating point element values in row-major order.

For example, the following represents a 3x2 matrix:
```
2 3
1.0 2.0
3.1 4.1
6   0
```

## Bayer-Ordered Images

Bayer-ordered images have one red, green or blue value per pixel, and the pixels are interleaved in a mosaic pattern. In
order to get an equivalent RGB image one must demosaic the image by interpolating the missing red, green, and blue
values. Bayer-ordered images are addressed by 2x2 blocks of such pixels, where each block has one red and blue value,
and two green values. A Bayer-ordered image may also be addressed as a single-channel (`CL_R`) image to get one color
channel at a time.
